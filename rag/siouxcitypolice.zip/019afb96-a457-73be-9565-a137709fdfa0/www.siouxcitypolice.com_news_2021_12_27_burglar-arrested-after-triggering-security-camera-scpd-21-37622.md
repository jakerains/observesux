---
url: "https://www.siouxcitypolice.com/news/2021/12/27/burglar-arrested-after-triggering-security-camera-scpd-21-37622"
title: "Burglar arrested after triggering security camera - SCPD #21-37622 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Burglar arrested after triggering security camera - SCPD \#21-37622](https://www.siouxcitypolice.com/news/2021/12/27/burglar-arrested-after-triggering-security-camera-scpd-21-37622)

## December 27, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Officers responded to a report of a suspicious subject on Dec. 26th at 4:15 a.m. in the 6200 block of Tiger Ave in the Whispering Creek area of town after a homeowner was alerted to someone triggering his security camera.

When Officers arrived in the area, they located 39-year-old Charles C. Gordon of Sioux City hiding under a pickup truck parked in the street near the residence.

The camera footage showed Gordon checking car handles in the homeowner’s driveway before making his way to the garage of the home. Gordon then entered the garage and took items from a car parked inside. The items he took from the home were recovered in the truck that he had been hiding under.

Detectives were called in to continue the investigation and connected Gordon to four other burglaries that he had committed previously during October and December.

Gordon was charged with 2nd degree burglary for entering the residence, and four counts of 3rd degree burglary of a motor vehicle.

![Mugshot of Charles Gordon who was arrested for burglary on December 26, 2021.](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/2c2bd924-1462-4509-8f2c-58355d7ec6ef/Gordon+12-26-21.jpg)

![Image of Gordon captured on security camera.](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/499088dd-cc60-42e0-9590-53095c85cba0/Gordon+12-26-21+on+Roing.jpg)

Gordon triggered a homeowners security camera as he checked car doors in the driveway.

Share

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[security cameras](https://www.siouxcitypolice.com/news/tag/security+cameras),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2021/12/27/two-arrested-after-attacking-a-man-with-a-hatchet-scpd-21-36946)[**December 27, 2021**\\
\\
Two arrested after attacking a man with a hatchet - SCPD #21-36946](https://www.siouxcitypolice.com/news/2021/12/27/two-arrested-after-attacking-a-man-with-a-hatchet-scpd-21-36946)

[→](https://www.siouxcitypolice.com/news/2021/12/17/several-school-threats-meant-to-cause-alarm-investigated-students-charged)[**December 17, 2021**\\
\\
Several school threats meant to cause alarm investigated, students charged](https://www.siouxcitypolice.com/news/2021/12/17/several-school-threats-meant-to-cause-alarm-investigated-students-charged)