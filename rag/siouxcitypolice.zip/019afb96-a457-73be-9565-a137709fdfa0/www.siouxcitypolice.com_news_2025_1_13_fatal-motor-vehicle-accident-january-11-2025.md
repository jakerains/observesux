---
url: "https://www.siouxcitypolice.com/news/2025/1/13/fatal-motor-vehicle-accident-january-11-2025"
title: "Fatal Motor Vehicle Accident January 11, 2025 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Fatal Motor Vehicle Accident January 11, 2025](https://www.siouxcitypolice.com/news/2025/1/13/fatal-motor-vehicle-accident-january-11-2025)

## January 13, 2025 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Released January 12, 2025 at 10:00 pm - On Jan. 11, the Sioux City Police Department and several area law enforcement agencies responded to a rollover accident on Highway 20 eastbound near mile marker 1.

Based on the preliminary investigation, a 2004 Jeep Cherokee was traveling eastbound on Hwy 20 when the driver lost control of the vehicle. The vehicle left the roadway and rolled over several times down the embankment.

The driver was a 19-year-old man from South Sioux City, Neb. and was critically injured in the accident.

He was transported to a local hospital and later died of his injures.

The name of the deceased is not being released at this time pending notification of his family.

This incident remains under investigation.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Fatality Accident](https://www.siouxcitypolice.com/news/tag/Fatality+Accident)

[←](https://www.siouxcitypolice.com/news/2025/2/10/fatality-accident-on-feb-7-2025-25sc03446)[**February 10, 2025**\\
\\
Fatality Accident on Feb. 7, 2025 - 25SC03446](https://www.siouxcitypolice.com/news/2025/2/10/fatality-accident-on-feb-7-2025-25sc03446)

[→](https://www.siouxcitypolice.com/news/2024/10/21/ois-on-october-20-2024-in-the-2500-block-of-1st-street)[**October 21, 2024**\\
\\
OIS on October 20, 2024 in the 2500 block of 1st Street](https://www.siouxcitypolice.com/news/2024/10/21/ois-on-october-20-2024-in-the-2500-block-of-1st-street)