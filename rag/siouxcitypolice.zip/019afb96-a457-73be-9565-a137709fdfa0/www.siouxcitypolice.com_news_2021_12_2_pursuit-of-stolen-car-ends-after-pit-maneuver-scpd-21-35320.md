---
url: "https://www.siouxcitypolice.com/news/2021/12/2/pursuit-of-stolen-car-ends-after-pit-maneuver-scpd-21-35320"
title: "Pursuit of stolen car ends after PIT maneuver - SCPD #21-35320 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Pursuit of stolen car ends after PIT maneuver - SCPD \#21-35320](https://www.siouxcitypolice.com/news/2021/12/2/pursuit-of-stolen-car-ends-after-pit-maneuver-scpd-21-35320)

## December 2, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Dec. 2 at 8:12 a.m., the Sioux City Police Department received a report a suspicious car in the parking lot of the Sioux City Country Club, 4001 Jackson St.

The complainant provided a plate for the car and indicated that the driver of the suspicious car was showing signs of intoxication.

The car, a 2014 Kia Sorento, had been reported stolen on Nov. 29 to the department.

Officers located the car at 37th and Jackson Streets and attempted to stop the car. The driver of the car refused to yield to officers and attempted to elude them.

The pursuit ended after officers conducted a pursuit intervention technique or PIT maneuver in the 2300 block of Riverside Blvd. and the female driver was taken into custody without further resistance.

Arrested was 26-year-old Makayla C. Nellist of Sioux City. She was charged with 1st degree theft, felony eluding, and operating while intoxicated. Additional traffic violations that occurred during the pursuit will be pending further review of in-car-cameras.

No injuries were reported and the stolen car and a police car received minor damage. No other cars or property were damaged during the pursuit.

The Iowa State Patrol provide assistance during the pursuit.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/12/6/identification-made-of-body-recovered-from-big-sioux-river-in-august-scpd-21-24517)[**December 06, 2021**\\
\\
Identification made of body recovered from Big Sioux River in August - SCPD #21-24517](https://www.siouxcitypolice.com/news/2021/12/6/identification-made-of-body-recovered-from-big-sioux-river-in-august-scpd-21-24517)

[→](https://www.siouxcitypolice.com/news/2021/12/2/pedestrian-dies-after-being-struck-by-car-at-w-4th-amp-bluff-st-scpd-21-35220)[**December 02, 2021**\\
\\
Pedestrian dies after being struck by car at W. 4th & Bluff St. - SCPD #21-35220](https://www.siouxcitypolice.com/news/2021/12/2/pedestrian-dies-after-being-struck-by-car-at-w-4th-amp-bluff-st-scpd-21-35220)