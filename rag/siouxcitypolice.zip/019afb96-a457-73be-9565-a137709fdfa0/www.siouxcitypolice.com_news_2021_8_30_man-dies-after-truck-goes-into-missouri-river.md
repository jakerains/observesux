---
url: "https://www.siouxcitypolice.com/news/2021/8/30/man-dies-after-truck-goes-into-missouri-river"
title: "Man dies after truck goes into Missouri River.  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man dies after truck goes into Missouri River.](https://www.siouxcitypolice.com/news/2021/8/30/man-dies-after-truck-goes-into-missouri-river)

## August 30, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Aug. 28 at 10:27 p.m., the Sioux City Police Department received a report of a pick-up truck that had lost control while traveling south on I29 at about mile marker 150 and drove into the Missouri River.

Responding officers located where the vehicle went into the river and found that the vehicle was fully submerged.

Sioux City Fire & Rescue and the Urban Search and Rescue Task Force 1 Dive Team began efforts to retrieve the vehicle from the water but were unsuccessful during the overnight hours due to conditions.

On Aug. 29 recovery efforts resumed and at 11:21 a.m., divers were successful in recovering the truck from the water.

The remains of the driver were recovered in the vehicle and a positive identification has been made and we are in contact with his family.

Officers identified 69-year-old Gerald M. Reed of Smithland, Iowa as the driver of the pick-up truck that died after his vehicle went into the Missouri river on Aug. 28 near mile marker 150.

We want to express our condolences to his family for their loss.

This accident is under investigation but it appears that the weather was a factor as this accident occurred during a period of heavy rain.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Fatality Accident](https://www.siouxcitypolice.com/news/tag/Fatality+Accident),

[Accidents](https://www.siouxcitypolice.com/news/tag/Accidents)

[←](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-stabbing-at-convenience-store-scpd-21-26750)[**September 29, 2021**\\
\\
Man arrested after stabbing at convenience store - SCPD #21-26750](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-stabbing-at-convenience-store-scpd-21-26750)

[→](https://www.siouxcitypolice.com/news/2021/8/23/arrest-made-in-esquire-club-arson-scpd-21-24584)[**August 23, 2021**\\
\\
Arrest made in Esquire Club arson – SCPD #21-24584](https://www.siouxcitypolice.com/news/2021/8/23/arrest-made-in-esquire-club-arson-scpd-21-24584)