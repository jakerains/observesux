---
url: "https://www.siouxcitypolice.com/news/2022/5/2/stabbing-amp-shots-fired-in-500-block-of-s-irene-scpd-22-8874"
title: "Stabbing & shots fired in 500 block of S. Irene - SCPD #22-8874 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Stabbing & shots fired in 500 block of S. Irene - SCPD \#22-8874](https://www.siouxcitypolice.com/news/2022/5/2/stabbing-amp-shots-fired-in-500-block-of-s-irene-scpd-22-8874)

## May 2, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On April 5 at 12:12 p.m., the Sioux City Police Department responded to a report of a shot being fired in the area of S. Irene and Washington Ave.

Responding officers found that an adult male had been stabbed and went to MercyOne to be treated for a non-life-threatening injury.

The initial investigation found that three roommates of a residence in the 500 block of S. Irene had gotten into an altercation inside their home. One of the roommates armed himself with a knife and stabbed the other roommate.

The suspect then fled the residence along with an adult-male and an adult-female that had been in his company. The third roommate that was not stabbed gave chase to the trio and one of the fleeing group fired a gun in the pursuing roommate’s direction.

No one was injured by the gun fire.

All subjects involved in this incident are adults.

All the parties involved have been identified.

The names of the persons involved in this incident are not being released at this time as detectives are gathering additional information and this is an on-going investigation.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

[←](https://www.siouxcitypolice.com/news/2022/5/2/man-arrested-for-stabbing-in-1700-block-of-pierce-st-scpd-22-10599)[**May 02, 2022**\\
\\
Man arrested for stabbing in 1700 block of Pierce St. - SCPD #22-10599](https://www.siouxcitypolice.com/news/2022/5/2/man-arrested-for-stabbing-in-1700-block-of-pierce-st-scpd-22-10599)

[→](https://www.siouxcitypolice.com/news/2022/5/2/shooting-in-1400-block-of-w-3rd-st-scpd-22-8729)[**May 02, 2022**\\
\\
Shooting in 1400 block of W. 3rd St. - SCPD #22-8729](https://www.siouxcitypolice.com/news/2022/5/2/shooting-in-1400-block-of-w-3rd-st-scpd-22-8729)