---
url: "https://www.siouxcitypolice.com/news/2024/6/24/scpd-survey"
title: "SCPD Survey — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [SCPD Survey](https://www.siouxcitypolice.com/news/2024/6/24/scpd-survey)

## June 24, 2024 [Valerie Rose](https://www.siouxcitypolice.com/news?author=622f948bc3ddaa77da76fe6d)

The Sioux City Police Department encourages community involvement and desires our resident’s help in directing the efforts of their police department.  As such, we are requesting our residents take the opportunity to complete the police department’s on-line survey.  The survey should only take about 5 minutes to complete.

The survey can be taken by entering the following web address into any web browser or by scanning the QR code.

![](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/0c939154-ddd4-45f2-a842-d072819c9e79/SCPD+Survey+QR+Code.png)

[https://www.surveymonkey.com/r/SCPDsurvey](https://www.surveymonkey.com/r/SCPDsurvey)

Share

[←](https://www.siouxcitypolice.com/news/2024/10/21/ois-on-october-20-2024-in-the-2500-block-of-1st-street)[**October 21, 2024**\\
\\
OIS on October 20, 2024 in the 2500 block of 1st Street](https://www.siouxcitypolice.com/news/2024/10/21/ois-on-october-20-2024-in-the-2500-block-of-1st-street)

[→](https://www.siouxcitypolice.com/news/2023/12/6/homicide)[**December 06, 2023**\\
\\
Homicide 513 9th Street](https://www.siouxcitypolice.com/news/2023/12/6/homicide)