---
url: "https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-damaging-cars-scpd-21-27678"
title: "Man arrested after damaging cars - SCPD #21-27678 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man arrested after damaging cars - SCPD \#21-27678](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-damaging-cars-scpd-21-27678)

## September 29, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Sept. 20 at 3:18 a.m., the Sioux City Police Department responded to a report of a subject damaging cars parked next to an apartment building in the 1000 block of Pierce St.

Officers arrested 30-year-old Hagos T. Mengsteab of Sioux City and charged him with 8 counts of 4th degree criminal mischief after they determined that he had broken windows and dented parked cars by throwing rocks at them.

Mengsteab, who showed signs of intoxication, was involved in an argument with an unknown male and then started damaging the cars. The other male was not involved in causing any damage and was not charged in this matter.

The initial estimate of total damage caused is to be $2,800.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty_

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/9/29/shooing-in-the-200-block-of-nebraska-st-scpd-21-28188)[**September 29, 2021**\\
\\
Shooing in the 200 block of Nebraska St - SCPD #21-28188](https://www.siouxcitypolice.com/news/2021/9/29/shooing-in-the-200-block-of-nebraska-st-scpd-21-28188)

[→](https://www.siouxcitypolice.com/news/2021/9/29/man-charged-for-firing-gun-at-occupied-car-scpd-21-27288)[**September 29, 2021**\\
\\
Man charged for firing gun at occupied car - SCPD #21-27288](https://www.siouxcitypolice.com/news/2021/9/29/man-charged-for-firing-gun-at-occupied-car-scpd-21-27288)