---
url: "https://www.siouxcitypolice.com/news/2021/11/1/robbery-of-kampk-quick-corner-scpd-21-31227"
title: "Robbery of K&K Quick Corner - SCPD #21-31227 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Robbery of K&K Quick Corner - SCPD \#21-31227](https://www.siouxcitypolice.com/news/2021/11/1/robbery-of-kampk-quick-corner-scpd-21-31227)

## November 1, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Oct. 22 at 1:41 p.m., the Sioux City Police Department received a report of a robbery at the K and K Quick Corner convenience store, 1401 Court St. when a person threatened the clerk by implying he had a gun. The suspect stole money and tobacco products before fleeing the store.

Thanks to several witnesses providing information to investigating officers, the suspect was located in house in the 1400 block of Court St.

Detectives have charged 19-year-old Jaden Cline of Sioux City with 2nd degree robbery and was booked into the Woodbury County Jail.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

[←](https://www.siouxcitypolice.com/news/2021/12/2/pedestrian-dies-after-being-struck-by-car-at-w-4th-amp-bluff-st-scpd-21-35220)[**December 02, 2021**\\
\\
Pedestrian dies after being struck by car at W. 4th & Bluff St. - SCPD #21-35220](https://www.siouxcitypolice.com/news/2021/12/2/pedestrian-dies-after-being-struck-by-car-at-w-4th-amp-bluff-st-scpd-21-35220)

[→](https://www.siouxcitypolice.com/news/2021/11/1/removal-of-abandoned-vehicles-to-begin-in-november)[**November 01, 2021**\\
\\
Removal of abandoned vehicles to begin in November](https://www.siouxcitypolice.com/news/2021/11/1/removal-of-abandoned-vehicles-to-begin-in-november)