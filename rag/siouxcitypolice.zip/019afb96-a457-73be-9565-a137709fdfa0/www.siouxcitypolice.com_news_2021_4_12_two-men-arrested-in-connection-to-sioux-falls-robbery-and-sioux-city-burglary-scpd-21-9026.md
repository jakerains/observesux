---
url: "https://www.siouxcitypolice.com/news/2021/4/12/two-men-arrested-in-connection-to-sioux-falls-robbery-and-sioux-city-burglary-scpd-21-9026"
title: "Two men arrested in connection to Sioux Falls robbery and Sioux City burglary – SCPD #21-9026 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Two men arrested in connection to Sioux Falls robbery and Sioux City burglary – SCPD \#21-9026](https://www.siouxcitypolice.com/news/2021/4/12/two-men-arrested-in-connection-to-sioux-falls-robbery-and-sioux-city-burglary-scpd-21-9026)

## April 12, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On April 9 at 12:10 p.m. a Woodbury County Deputy located a stolen 2010 Chrysler Town and Country minivan in the 4300 block of Stone Ave.

The minivan was stolen during a robbery on March 25 in Sioux Falls, S.D. by a man armed with a handgun.

When the deputy approached the vehicle, a subject exited and ran. He was apprehended a short distance later.

The subject apprehended was identified as 18-year-old Chase B. Van Hofwegen of Sioux City.

Detectives with the Sioux City Police Department had been investigating Chase Van Hofwegen and his twin brother 18-year-old Chance Van Hofwegen of Sioux City in connection to the burglary of Select Mart, 4103 Floyd Blvd, on March 29.

Detectives located Chance in a residence 5309 Hwy 75n. lot 320 when they served a search warrant in connection to the Sioux Falls robbery and the Sioux City burglary.

During the search of the Van Hofwegen residence, detectives recovered $17,000 worth of stolen merchandise from Select Mart.

Chase Van Hofwegen was charged with Eluding a 1st degree Theft, 2nd degree Theft, and Eluding a Peace Officer.

Chance Van Hof Wegen was charged with 1st degree theft and 2nd degree Theft.

Both men were booked into Woodbury County Jail.

The investigations into the robbery and burglary are on-going.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[crime sux](https://www.siouxcitypolice.com/news/tag/crime+sux)

[←](https://www.siouxcitypolice.com/news/2021/4/15/scpd-selling-autism-awareness-shoulder-patch-during-april)[**April 15, 2021**\\
\\
SCPD selling Autism Awareness shoulder patch during April](https://www.siouxcitypolice.com/news/2021/4/15/scpd-selling-autism-awareness-shoulder-patch-during-april)

[→](https://www.siouxcitypolice.com/news/2021/2/26/scpd-provides-snapshot-of-2020-city-crime-stats)[**February 26, 2021**\\
\\
SCPD provides snapshot of 2020 city crime stats](https://www.siouxcitypolice.com/news/2021/2/26/scpd-provides-snapshot-of-2020-city-crime-stats)