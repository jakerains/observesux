---
url: "https://www.siouxcitypolice.com/news/2022/9/27/man-suffers-stab-wound-during-robbery-attempt-scpd-22sc27238"
title: "Man suffers stab wound during robbery attempt - SCPD 22SC27238 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man suffers stab wound during robbery attempt - SCPD 22SC27238](https://www.siouxcitypolice.com/news/2022/9/27/man-suffers-stab-wound-during-robbery-attempt-scpd-22sc27238)

## September 27, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On September 25 at about 1:56 pm, Sioux City Police Officers were sent to the area of 7th & Courts St in Sioux City for a report of a man bleeding.

Officers located an adult-male that was suffering from a severe but non-life-threatening laceration to his head. He was taken to a local hospital for treatment.

The investigation determined that the victim had gone to a residence in the 1100 block of 7th St. to speak with someone that lived there. When the victim left the house, Hamilton Veliz-Cantor who been staying at the residence, began following him.

Veliz-Cantor, who was armed with a kitchen knife, confronted the victim, demanded money, and then cut the victim with the knife after he said he did not have any money.

Officers located Veliz-Cantor at his residence and took him into custody.

Detectives have charged 24-year-old Hamilton Veliz-Cantor with going armed with intent, 1st degree robbery, and willful injury.

They are also working with the Department of Homeland Security as Veliz-Cantor has previously been deported at least once and illegally returned to the country.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2022/9/27/teen-stabbed-by-unknown-man-during-altercation-22sc27238)[**September 27, 2022**\\
\\
Teen stabbed by unknown man during altercation - 22SC27238](https://www.siouxcitypolice.com/news/2022/9/27/teen-stabbed-by-unknown-man-during-altercation-22sc27238)

[→](https://www.siouxcitypolice.com/news/2022/9/23/scpd-investigates-post-on-social-media-that-caused-school-lock-outs)[**September 23, 2022**\\
\\
SCPD investigates post on social media that caused school lock-outs](https://www.siouxcitypolice.com/news/2022/9/23/scpd-investigates-post-on-social-media-that-caused-school-lock-outs)