---
url: "https://www.siouxcitypolice.com/news/2022/3/29/shooting-700-block-of-18th-street-scpd-22-8110"
title: "Shooting 700 block of 18th Street - SCPD #22-8110 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shooting 700 block of 18th Street - SCPD \#22-8110](https://www.siouxcitypolice.com/news/2022/3/29/shooting-700-block-of-18th-street-scpd-22-8110)

## March 29, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

**Update April 6 at 5:09 p.m.** \- An updated description of the suspect is that of a black male with short hair and a tattoo on his face.

**Original release on March 29, 2022 at 12:15 p.m.** \- On March 29 at 9:52 a.m., the Sioux City Police Department received reports of a shooting in the 700 block of 18th St.

Responding officers located a 16-year-old male at the corner of 16th and Jackson Street suffering from multiple gunshot wounds. He was transported to MercyOne with life-threatening injuries.

Initial information gathered indicated that the victim was walking on the 700 block of 18th Street when he was confronted by an unknown male party who started a physical altercation with him. During this altercation, the other man produced a handgun and shot the victim. The victim ran from the scene of the shooting to where he was located.

The person with the gun was described as a 6-foot-tall black male with dreadlocks  (this description was updated to a black male, short hair, and a tattoo on his face) who was last seen wearing a gray hooded sweatshirt. He is considered armed and dangerous.

Detectives are investigating a motive at this time, as this appears to be an unprovoked attack.

Anyone with information on the identity of the suspect is asked to call the Sioux City Police Department or Crime Stoppers at 258-TIPS (8477)

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2022/5/2/shots-fired-call-results-in-kidnapping-arrest-scpd-8616)[**May 02, 2022**\\
\\
Shots fired call results in kidnapping arrest - SCPD #8616](https://www.siouxcitypolice.com/news/2022/5/2/shots-fired-call-results-in-kidnapping-arrest-scpd-8616)

[→](https://www.siouxcitypolice.com/news/2022/3/21/shooting-1600-block-of-nebraska-st-scpd-22-7338)[**March 21, 2022**\\
\\
Shooting 1600 block of Nebraska St. - SCPD #22-7338](https://www.siouxcitypolice.com/news/2022/3/21/shooting-1600-block-of-nebraska-st-scpd-22-7338)