---
url: "https://www.siouxcitypolice.com/news/2022/5/16/scpd-holds-annual-awards-ceremony"
title: "SCPD holds annual awards ceremony  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [SCPD holds annual awards ceremony](https://www.siouxcitypolice.com/news/2022/5/16/scpd-holds-annual-awards-ceremony)

## May 16, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

The Sioux City Police Department held its annual awards ceremony on May 16 to recognize the accomplishments of civilians, volunteers, civilian staff, and officers during the past year.

Chief Rex Mueller, Chief of Police for the Sioux City Police Department presided over the ceremony and handed out awards for volunteering, lifesaving, and efforts made to improve relationships with the community and improve the department.

The following a list of the recipients and the awards.

Lifesaving – Officer Brooke Davies & Officer Brent Heald

Lifesaving – Officer Donald Schroeder & Officer Mike Simons

Lifesaving – Jeremy McClure, Officer Josh Fleckenstein & Officer Mackenzie Neely

Lifesaving – Officer Mackenzie Neely & Officer Lucas Petersen

Lifesaving – Officer Casey McBride

Community Policing – Officer Mike Koehler

Community Policing – Lt. Judy Kellen, Officer Ryan Moritz & Marie Divis

Chief’s Appreciation - Gary Niles

Chief’s Appreciation – Kevin Sampson

Chief’s Appreciation – Dr. Ryan Meis

Achievement – Capt. Mark Kirkpatrick, Lt. Kevin Heineman, Sgt. Jay Hoogendyk & Officer Marc Hein

Chief’s Commendation – Judy Kellen & Chris Groves

Chief’s Commendation – Jerry Levay

Chief’s Citation – Richard Crosby

Chief’s Citation – Forde Fairchild

Civilian of the Year – Sarah Hadden

Officer of the Year – Detective Josh Tyler

We wish to congratulate this year’s recipients.

Share

[←](https://www.siouxcitypolice.com/news/2022/6/2/june-1-shots-fired-scpd-22-14848)[**June 02, 2022**\\
\\
June 1 shots fired - SCPD #22-14848](https://www.siouxcitypolice.com/news/2022/6/2/june-1-shots-fired-scpd-22-14848)

[→](https://www.siouxcitypolice.com/news/2022/5/2/obin90x6dzze25tfqt7rt0dvs54qa6)[**May 02, 2022**\\
\\
Pursuit of burglary suspects ends in Le Mars - SCPD #22-10941](https://www.siouxcitypolice.com/news/2022/5/2/obin90x6dzze25tfqt7rt0dvs54qa6)