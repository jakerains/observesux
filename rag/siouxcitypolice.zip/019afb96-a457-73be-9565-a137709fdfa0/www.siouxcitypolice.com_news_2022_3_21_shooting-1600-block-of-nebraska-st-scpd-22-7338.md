---
url: "https://www.siouxcitypolice.com/news/2022/3/21/shooting-1600-block-of-nebraska-st-scpd-22-7338"
title: "Shooting 1600 block of Nebraska St. - SCPD #22-7338 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shooting 1600 block of Nebraska St. - SCPD \#22-7338](https://www.siouxcitypolice.com/news/2022/3/21/shooting-1600-block-of-nebraska-st-scpd-22-7338)

## March 21, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

**Update on April 25 at 10:20 a.m.** \- On April 15, 23-year-old Ethan S. Hewitt was arrested on multiple warrants in connection to the investigation of the March 21 shooting in the 1600 block of Nebraska St.

Detectives had obtained warrants for Hewitt’s arrest while he recovered from gunshot wounds he received during the incident in which he went to a residence in the 1600 block of Nebraska St. and shot at the occupant of that residence.

The intended victim, who was also armed, fired back at Hewitt striking him. The warrants were for attempted murder, intimidation with a dangerous weapon, attempted burglary, going armed with intent, possession of a firearm by a felon, trafficking stolen firearms, and driving charges.

Hewitt was taken into custody at his residence without incident.

**Original release on March 21**\- On March 21 at 4:15 a.m. the Sioux City Police Department received a report of shots being fired in the 1600 block of Nebraska St.

Responding officers located a subject who reported that two men armed with guns approached his residence in the 1600 block of Nebraska St.

When he confronted one of the men through an open window, the subject outside fired a shot and then ran to the front door. The resident armed himself and when the subject outside shot at him, the resident shot back.

The person outside that had fired the shots fled the area and a few minutes later arrived at UnityPoint St. Luke’s with life-threatening injuries. He remains hospitalized at the time of this release.

The second subject that went to the residence also fled the area and has not been located. His identity is not known at this time.

The resident and the subject shot know each other and this incident was part of an on-going feud between the men.

No charges have been filed at this time.

As this is an on-going investigation, no names are being released at this time.

**_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._**

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

[←](https://www.siouxcitypolice.com/news/2022/3/29/shooting-700-block-of-18th-street-scpd-22-8110)[**March 29, 2022**\\
\\
Shooting 700 block of 18th Street - SCPD #22-8110](https://www.siouxcitypolice.com/news/2022/3/29/shooting-700-block-of-18th-street-scpd-22-8110)

[→](https://www.siouxcitypolice.com/news/2022/3/21/pedestrian-struck-and-killed-on-i29-scp-22-6682)[**March 21, 2022**\\
\\
Pedestrian struck and killed on I29 - SCP #22-6682](https://www.siouxcitypolice.com/news/2022/3/21/pedestrian-struck-and-killed-on-i29-scp-22-6682)