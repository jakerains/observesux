---
url: "https://www.siouxcitypolice.com/news/2021/7/29/scpd-seeking-identity-of-man-suffering-from-medical-condition-scpd-21-22105"
title: "SCPD seeking identity of man suffering from medical condition – SCPD 21-22105 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [SCPD seeking identity of man suffering from medical condition – SCPD 21-22105](https://www.siouxcitypolice.com/news/2021/7/29/scpd-seeking-identity-of-man-suffering-from-medical-condition-scpd-21-22105)

## July 29, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

**UPDATE July 29 at 1:43 p.m.**

The man has been identified and we are in contact with his family.

**Original Release on July 29 at 12:05 p.m.**

On July 29 at 11:01 a.m., the Sioux City Police Department received reports of an adult male with no clothes on in the area of 3rd and Water St.

Officers located the man in the area of 5th and Wesley and approached him.

When officers made contact with the man, he became combative and tried to strike an officer and had to be restrained.

Once restrained, officers could tell that the person was suffering from a medical condition and was taken to MercyOne for medical treatment.

At the hospital, it was determined that he was suffering from a severe diabetic reaction and was unable to provide any information as to his identity.

The Sioux City Police Department is seeking the public’s help in identifying the man who is described as a white male in his 60s, balding gray hair, and a medium build. He is believed to live near the downtown area.

If you may possibly know who this person is, please call the Sioux City Police Department.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/7/30/roll-over-fatality-accident-at-17th-amp-main-scpd-21-22158)[**July 30, 2021**\\
\\
Roll-over fatality accident at 17th & Main – SCPD 21-22158](https://www.siouxcitypolice.com/news/2021/7/30/roll-over-fatality-accident-at-17th-amp-main-scpd-21-22158)

[→](https://www.siouxcitypolice.com/news/2021/7/28/detectives-continue-investigation-into-morning-shooting-scpd-21-21984)[**July 28, 2021**\\
\\
Detectives continue investigation into morning shooting – SCPD #21-21984](https://www.siouxcitypolice.com/news/2021/7/28/detectives-continue-investigation-into-morning-shooting-scpd-21-21984)