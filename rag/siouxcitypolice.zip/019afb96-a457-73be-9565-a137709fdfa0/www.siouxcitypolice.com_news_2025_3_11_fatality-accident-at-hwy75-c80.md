---
url: "https://www.siouxcitypolice.com/news/2025/3/11/fatality-accident-at-hwy75-c80"
title: "Fatality Accident at Hwy75 & C80 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Fatality Accident at Hwy75 & C80](https://www.siouxcitypolice.com/news/2025/3/11/fatality-accident-at-hwy75-c80)

## March 11, 2025 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

_On Tuesday March 11, 2025, at approximately 8:39AM, officers with the SiouX City Police Department were dispatched to an accident in the 5300 block of Hwy 75N._

_Once on scene, officers located a Dodge pick-up truck that was completely flipped over on it’s top. The driver of the truck was unconscious._

_The Dodge truck was pulling a trailer and was traveling southbound on Hwy 75 when a Jeep Commander pulled out in front of the Dodge truck from C-80. The Dodge truck struck the passenger side of the Jeep Commander, causing the Dodge truck to go down into the ditch on the west side of Hwy 75, and flip onto it’s top. The trailer being pulled by the Dodge truck swung around and struck a Toyota Rav 4 that was stopped at a stop sign on C-80, facing east._

_The driver of the Dodge truck died at the scene of the accident. The driver of the Jeep Commander was transported to a local hospital with minor injuries and was cited for Failure to Obey a Stop/Yield Sign._

_Iowa State Patrol, Plymouth County Sheriff’s Office, Hinton Police Department, Hinton Fire and EMS, Merrill Police Department, and Sioux City Fire and Rescue All responded to the scene of the accident. Hwy 75 South was shut down for approximately three hours while law enforcement conducted an investigation._

_At This time, the name of the deceased is not being released._

Share

[←](https://www.siouxcitypolice.com/news/2025/4/2/national-crime-victims-rights-week-events)[**April 02, 2025**\\
\\
National Crime Victims’ Rights Week Events](https://www.siouxcitypolice.com/news/2025/4/2/national-crime-victims-rights-week-events)

[→](https://www.siouxcitypolice.com/news/2025/2/24/ois-on-february-22-2025)[**February 24, 2025**\\
\\
OIS on February 22, 2025](https://www.siouxcitypolice.com/news/2025/2/24/ois-on-february-22-2025)