---
url: "https://www.siouxcitypolice.com/news/2021/4/17/tanner-pursuit"
title: "Man arrested after gun call ends in pursuit - SCPD #21-11075 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man arrested after gun call ends in pursuit - SCPD \#21-11075](https://www.siouxcitypolice.com/news/2021/4/17/tanner-pursuit)

## April 17, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

PRESS RELEASE April 17, 2021 4:35 p.m.

On April 17 at 3:26 p.m., the Sioux City Police received a report of a man displaying a gun at Sam’s MiniMart, 923 W. 7th St and threatening people.

Officers located a subject matching the description of the suspect parked in a car a short distance away and attempted to apprehend him.

The suspect refused the officer’s commands and started to drive away as the officer was trying to apprehend him.

The officer was dragged a short distance by the suspect’s car and suffered minor injuries.

The initial officer recognized the suspect as 26-year-old Austin M. Tanner of Sioux City, who also had active felony arrest warrants for probation violations.

Officers with the Sioux City Police Department and Woodbury County Sheriff’s Office pursued Tanner and during the pursuit, Tanner struck several parked cars and a car in traffic. No injuries were reported from these accidents.

The pursuit ended when Tanner lost control of his car on the I-29 on-ramp from Virginia St. where he was taken into custody.

Tanner was arrested for his warrants, interference with official acts causing injury, eluding, and multiple traffic violations.

At the time of this release, a weapon has not been located and is believed to have possibly been thrown from the car during the pursuit.

Officers are conducting a thorough search of the pursuit route looking for anything thrown from the car.

The investigation in the original gun call is on-going.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [sioux city police](https://www.siouxcitypolice.com/news/tag/sioux+city+police),

[crime sux](https://www.siouxcitypolice.com/news/tag/crime+sux),

[pursuit](https://www.siouxcitypolice.com/news/tag/pursuit)

[←](https://www.siouxcitypolice.com/news/2021/4/12/scpd-drug-take-back)[**April 19, 2021**\\
\\
Sioux City Police Department to participate in DEA 20th Drug Take Back Day](https://www.siouxcitypolice.com/news/2021/4/12/scpd-drug-take-back)

[→](https://www.siouxcitypolice.com/news/2021/4/15/scpd-selling-autism-awareness-shoulder-patch-during-april)[**April 15, 2021**\\
\\
SCPD selling Autism Awareness shoulder patch during April](https://www.siouxcitypolice.com/news/2021/4/15/scpd-selling-autism-awareness-shoulder-patch-during-april)