---
url: "https://www.siouxcitypolice.com/news/2021/12/15/doorbell-camera-helps-capture-porch-pirate"
title: "Doorbell camera helps capture porch pirate  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Doorbell camera helps capture porch pirate](https://www.siouxcitypolice.com/news/2021/12/15/doorbell-camera-helps-capture-porch-pirate)

## December 15, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Dec. 12 at 3:24 p.m. in the 4000 block of Morningside Ave., officers with the Sioux City Police Department took 37-year-old Casey Andersen into custody on warrants issued for his arrest.

While arresting Andersen, officers noticed that not only did he match the description of a suspect who took packages off of a front porch in the 2200 block of S. Olive St. on Dec. 9, but he was also wearing the exact same clothes at the time of his arrest. This determination was based on doorbell camera footage provided by the victim of the theft.

Officers booked Andersen into Woodbury County Jail for his warrants and also charged him with the Dec. 9 theft.

Further investigations into Andersen have connected him to an additional theft of packages on Dec. 8 in the 5000 block of Glenn Ave and charges have been referred to the Woodbury County Attorney's Office in that matter.

The doorbell camera footage provide was very valuable in connecting Andersen to these thefts. We encourage victims of package thefts to report the thefts and thank neighbors willing to provide valuable video evidence.

Doorbell camera helps catch porch pirate - YouTube

[Photo image of SiouxCityPolice](https://www.youtube.com/channel/UCaptXpbLXzjyGXARY3h3uOA?embeds_referring_euri=https%3A%2F%2Fwww.siouxcitypolice.com%2F)

SiouxCityPolice

448 subscribers

[Doorbell camera helps catch porch pirate](https://www.youtube.com/watch?v=A3siS54YgA0)

SiouxCityPolice

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

More videos

## More videos

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=A3siS54YgA0&embeds_referring_euri=https%3A%2F%2Fwww.siouxcitypolice.com%2F)

0:00

0:00 / 0:15

•Live

•

Share

_categories_ [Feature](https://www.siouxcitypolice.com/news/category/Feature)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Porch Pirates](https://www.siouxcitypolice.com/news/tag/Porch+Pirates),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2021/12/17/several-school-threats-meant-to-cause-alarm-investigated-students-charged)[**December 17, 2021**\\
\\
Several school threats meant to cause alarm investigated, students charged](https://www.siouxcitypolice.com/news/2021/12/17/several-school-threats-meant-to-cause-alarm-investigated-students-charged)

[→](https://www.siouxcitypolice.com/news/2021/12/14/investigations-made-into-threats-against-schools-on-dec-14-scpd-21-36549-amp-21-36565)[**December 14, 2021**\\
\\
Investigations made into threats against schools on Dec. 14 - SCPD #21-36549 & 21-36565](https://www.siouxcitypolice.com/news/2021/12/14/investigations-made-into-threats-against-schools-on-dec-14-scpd-21-36549-amp-21-36565)