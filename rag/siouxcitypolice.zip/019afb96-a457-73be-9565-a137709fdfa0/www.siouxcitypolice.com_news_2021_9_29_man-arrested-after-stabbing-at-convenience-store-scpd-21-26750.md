---
url: "https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-stabbing-at-convenience-store-scpd-21-26750"
title: "Man arrested after stabbing at convenience store - SCPD #21-26750 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man arrested after stabbing at convenience store - SCPD \#21-26750](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-stabbing-at-convenience-store-scpd-21-26750)

## September 29, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Sept. 11 at 1:26 p.m., the Sioux City Police Department responded to a report of a stabbing at Sarge’s Minimart, 1545 Indian Hills Blvd.

Responding officers found a 24-year-old woman suffering from lacerations that required medical attention and a 26-year-old Jasper Symons of Sioux City suffering from minor injuries.

Officers detained 24-year-old Amari Barker of Sioux City at the scene as he had caused the injuries.

Officers and detectives determined that there was an on-going feud between Barker and a 19-year-old female, both of whom are employees of Sarge’s, and some subjects who live across the street in the 1600 block of Indian Hills.

The subjects in the residence on Indian Hills were holding a yard sale and Barker and the female placed a sign next to the road that disparaged the people living at that residence.

In response to the sign, Symons and the 24-year-old woman came over to the store and damaged vehicles belonging to Barker and the other employee and a physical altercation broke out between the parties.

Barker armed himself with two swords and attacked 24-year-old female causing her injury. Barker then threw a brick at Symons causing him injury.

Barker was charged with two counts of aggravated assault.

Symons was charged with criminal mischief for damaging the cars.

Both men were booked into the Woodbury County Jail.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/9/29/man-charged-for-firing-gun-at-occupied-car-scpd-21-27288)[**September 29, 2021**\\
\\
Man charged for firing gun at occupied car - SCPD #21-27288](https://www.siouxcitypolice.com/news/2021/9/29/man-charged-for-firing-gun-at-occupied-car-scpd-21-27288)

[→](https://www.siouxcitypolice.com/news/2021/8/30/man-dies-after-truck-goes-into-missouri-river)[**August 30, 2021**\\
\\
Man dies after truck goes into Missouri River.](https://www.siouxcitypolice.com/news/2021/8/30/man-dies-after-truck-goes-into-missouri-river)