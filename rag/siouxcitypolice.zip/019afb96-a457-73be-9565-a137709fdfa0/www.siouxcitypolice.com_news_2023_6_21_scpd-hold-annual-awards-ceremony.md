---
url: "https://www.siouxcitypolice.com/news/2023/6/21/scpd-hold-annual-awards-ceremony"
title: "SCPD hold annual awards ceremony — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [SCPD hold annual awards ceremony](https://www.siouxcitypolice.com/news/2023/6/21/scpd-hold-annual-awards-ceremony)

## June 21, 2023 [Valerie Rose](https://www.siouxcitypolice.com/news?author=622f948bc3ddaa77da76fe6d)

_The Sioux City Police Department held its annual awards ceremony on May 1 8 to recognize the accomplishments of civilians, volunteers, civilian staff, and officers during the past year._

_Chief Rex Mueller, Chief of Police for the Sioux City Police Department presided over the ceremony and handed out awards for volunteering, lifesaving, and efforts made to improve relationships with the community and improve the department._

_The following a list of the recipients and the awards._

_Lifesaving – Officer Troy Hooks_

_Lifesaving – Officer Casey McBride & Officer Mike Simons_

_Lifesaving – Officer Kimberly Steele_

_Lifesaving – Officer Andrew Dutler_

_Lifesaving – Officer Dylan Frederickson_

_Lifesaving - Lt Hoogendyk & Officer Shawn Robinson_

_Community Policing – Officer Heather Skogman_

_Exceptional Duty – Officer Brennan Gill_

_Chief’s Appreciation - Bob DeSmidt_

_Chief’s Appreciation – Raul Gomez, Natnael Kifle, Joseph Olson and Jose Gutierrez_

_Chief’s Appreciation – Sunnybrook Church & Janet Coon_

_Chief’s Appreciation – Heartland Church & Pastor Gene Stockton_

_Volunteer Award - Officer Brent Heald_

_Achievement – Lt Heineman, Lt Hoogendyk, Sgt Aesoph, Officer Hein & Traci Markowski_

_Chief’s Commendation – FBI Agent Sam Roberts_

_Chief’s Commendation – SSCPD Detective Juaquin Orduno_

_Chief’s Commendation – FBI Agent Brad Colligan_

_US Attorney’s Victims Service Award – Detective Nate West_

_Civilian of the Year – Jakki Bata_

_Officer of the Year – Officer Valerie Rose_

_We wish to congratulate this year’s recipients._

Share

[←](https://www.siouxcitypolice.com/news/2023/6/21/calea-portal-for-public-input-created)[**June 21, 2023**\\
\\
CALEA portal for public input created](https://www.siouxcitypolice.com/news/2023/6/21/calea-portal-for-public-input-created)

[→](https://www.siouxcitypolice.com/news/2022/10/24/2022-town-hall-meeting-held)[**October 24, 2022**\\
\\
2022 Town Hall Meeting Held](https://www.siouxcitypolice.com/news/2022/10/24/2022-town-hall-meeting-held)