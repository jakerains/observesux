---
url: "https://www.siouxcitypolice.com/news/2021/11/1/2600-block-of-douglas-st-shooting-scpd-21-30633"
title: "2600 Block of Douglas St. Shooting - SCPD #21-30633 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [2600 Block of Douglas St. Shooting - SCPD \#21-30633](https://www.siouxcitypolice.com/news/2021/11/1/2600-block-of-douglas-st-shooting-scpd-21-30633)

## November 1, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Original Release on Oct. 16, 2021 at 7:16 am. - On I0/ 16/21 at 11 :54 PM, officers of the Sioux City Police Department were dispatched to Unity Point Health, 2720 Stone Park Blvd for a male party that came into the emergency room with a gunshot to his stomach area.

Officers spoke with multiple parties involved and officers were able to track down the location where the shooting occurred at.

The victim, Gary Wendte, 44, of Emerson, NE is being treated for his non-life-threatening injuries.

The case is still ongoing and at this time no further information will be released.

Share

[←](https://www.siouxcitypolice.com/news/2021/11/1/fatality-accident-in-the-2400-block-of-18th-st-scpd-21-30749)[**November 01, 2021**\\
\\
Fatality accident in the 2400 block of 18th St. - SCPD #21-30749](https://www.siouxcitypolice.com/news/2021/11/1/fatality-accident-in-the-2400-block-of-18th-st-scpd-21-30749)

[→](https://www.siouxcitypolice.com/news/2021/11/1/shooting-in-at-427-pierce-st-media-release)[**November 01, 2021**\\
\\
Shooting in at 427 Pierce St - SCPD #21-29897](https://www.siouxcitypolice.com/news/2021/11/1/shooting-in-at-427-pierce-st-media-release)