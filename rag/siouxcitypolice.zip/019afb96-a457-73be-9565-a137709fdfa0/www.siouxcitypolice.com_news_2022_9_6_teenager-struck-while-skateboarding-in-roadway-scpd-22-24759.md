---
url: "https://www.siouxcitypolice.com/news/2022/9/6/teenager-struck-while-skateboarding-in-roadway-scpd-22-24759"
title: "Teenager struck while skateboarding in roadway - SCPD #22-24759 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Teenager struck while skateboarding in roadway - SCPD \#22-24759](https://www.siouxcitypolice.com/news/2022/9/6/teenager-struck-while-skateboarding-in-roadway-scpd-22-24759)

## September 6, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On September 1 at 4:48 a.m., the Sioux City Police Department responded to a report of a skateboarder being struck by a vehicle in the Northbound lane at 2400 S. Lewis Blvd.

A teenaged-male was struck and was transported to the hospital with life-threatening injuries and has since passed away due to his injuries.

Initial information gathered was that the juvenile was riding a skateboard in the middle of the road and the driver was unable to avoid a collision due to the lack of time from observation of seeing the juvenile combined with the darkness of the roadway at that time of day.

SCPD Traffic Investigators were called out to the scene. This investigation is still on-going.

_Original release Sept. 1 with an update on Sept. 6._

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Accidents](https://www.siouxcitypolice.com/news/tag/Accidents),

[Fatality Accident](https://www.siouxcitypolice.com/news/tag/Fatality+Accident)

[←](https://www.siouxcitypolice.com/news/2022/9/6/speed-violations-and-accident-trend-down-after-cameras-installed)[**September 06, 2022**\\
\\
Speed violations and accident trend down after cameras installed](https://www.siouxcitypolice.com/news/2022/9/6/speed-violations-and-accident-trend-down-after-cameras-installed)

[→](https://www.siouxcitypolice.com/news/2022/8/16/hsi-sioux-city-police-department-investigation-results-in-30-year-sentence-for-child-predator)[**August 16, 2022**\\
\\
HSI, Sioux City police department investigation results in 30-year sentence for child predator](https://www.siouxcitypolice.com/news/2022/8/16/hsi-sioux-city-police-department-investigation-results-in-30-year-sentence-for-child-predator)