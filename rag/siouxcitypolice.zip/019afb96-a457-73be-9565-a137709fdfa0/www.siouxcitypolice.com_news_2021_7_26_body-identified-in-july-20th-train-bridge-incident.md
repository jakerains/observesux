---
url: "https://www.siouxcitypolice.com/news/2021/7/26/body-identified-in-july-20th-train-bridge-incident"
title: "Body identified in July 20th train bridge incident  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Body identified in July 20th train bridge incident](https://www.siouxcitypolice.com/news/2021/7/26/body-identified-in-july-20th-train-bridge-incident)

## July 26, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On July 20 at 12:04 p.m., an individual was seen walking across the train bridge connecting Sioux City to South Sioux City. The person was witnessed falling into the river near the Iowa side. It is unclear as to whether the person fell, or intentionally jumped off the bridge.

Sioux City Fire Rescue and the South Sioux City Fire Department scrambled search and rescue boats to locate the person, to no avail.

On July 23 at 9:30 a.m., a boater discovered a body floating in the river about one mile north of Dakota City, Nebraska. Sioux City Fire Rescue recovered a body that matched the description from the incident on the train bridge on the July 20.

The body has been identified as 32-year-old Timmy Nawanna of Sioux City. We want to express our condolences to the Nawanna family.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/7/26/suspect-in-mavericks-shooting-arrested-scpd-20-38938)[**July 26, 2021**\\
\\
Suspect in Mavericks shooting arrested - SCPD 20-38938](https://www.siouxcitypolice.com/news/2021/7/26/suspect-in-mavericks-shooting-arrested-scpd-20-38938)

[→](https://www.siouxcitypolice.com/news/2021/7/6/early-morning-shooting-reported-at-after-hours-club-scpd-21-19532)[**July 06, 2021**\\
\\
Early morning shooting reported at after hours club - SCPD #21-19532](https://www.siouxcitypolice.com/news/2021/7/6/early-morning-shooting-reported-at-after-hours-club-scpd-21-19532)