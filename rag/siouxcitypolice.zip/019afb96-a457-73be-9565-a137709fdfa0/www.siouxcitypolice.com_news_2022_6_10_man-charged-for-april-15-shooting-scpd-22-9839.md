---
url: "https://www.siouxcitypolice.com/news/2022/6/10/man-charged-for-april-15-shooting-scpd-22-9839"
title: "MAN CHARGED FOR APRIL 15 SHOOTING - SCPD #22-9839 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [MAN CHARGED FOR APRIL 15 SHOOTING - SCPD \#22-9839](https://www.siouxcitypolice.com/news/2022/6/10/man-charged-for-april-15-shooting-scpd-22-9839)

## June 10, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

The Sioux City Police Department have arrested 18-year-old Jalond J. Hills of Sioux City for a shooting that occurred on April 15 in an apartment in the 2200 block of Gibson Street.

On that date, the department responded to a report of a shooting and found that an adult-female suffering a non-life-threatening injury due to a gunshot.

Detectives determined that Hills had been in a bedroom of the apartment with the victim drinking alcohol and smoking marijuana. Another man who was sleeping was also present in the bedroom.

The victim removed a handgun from the sleeping man and Hills attempted to take the gun from the victim. The two struggled over the firearm and it discharged striking the victim in the leg.

After the shot was fired, Hills gave the gun to a third who had been in the apartment and all three men fled the apartment.

Detectives determined that the person that Hills gave the gun to is a known convicted felon who is prohibited from possessing firearms.

Hills was booked into the Woodbury County Jail on June 9 and was charged with discharging a firearm in city limits, prohibited transfer of a firearm to an unauthorized person, possession of a controlled substance with intent to deliver, and failure to affix a drug tax stamp.

The investigation into this shooting is on-going.

**_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._**

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [shooting](https://www.siouxcitypolice.com/news/tag/shooting),

[Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2022/6/10/murder-on-june-9-scpd-22-15694)[**June 10, 2022**\\
\\
Murder on June 9 - SCPD #22-15694](https://www.siouxcitypolice.com/news/2022/6/10/murder-on-june-9-scpd-22-15694)

[→](https://www.siouxcitypolice.com/news/2022/6/2/june-1-shots-fired-scpd-22-14848)[**June 02, 2022**\\
\\
June 1 shots fired - SCPD #22-14848](https://www.siouxcitypolice.com/news/2022/6/2/june-1-shots-fired-scpd-22-14848)