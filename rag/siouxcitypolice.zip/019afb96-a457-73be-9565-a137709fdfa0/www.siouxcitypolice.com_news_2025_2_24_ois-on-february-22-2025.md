---
url: "https://www.siouxcitypolice.com/news/2025/2/24/ois-on-february-22-2025"
title: "OIS on February 22, 2025  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [OIS on February 22, 2025](https://www.siouxcitypolice.com/news/2025/2/24/ois-on-february-22-2025)

## February 24, 2025 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Released on Feb. 22, 2025 at 6:30 a.m. - On Saturday February 22, 2023, at approximately 3:38 AM officers with the Sioux City Police Department initiated a traffic stop on a vehicle near 18th and Grandview Blvd. During the stop, officers learned an occupant of the vehicle was wanted for felony criminal warrants. As officers attempted to take the wanted individual into custody, the suspect resisted arrest, and an officer discharged their firearm. Officers immediately initiated lifesaving measures to care for the injured suspect, who was later transported to a local hospital for treatment. The suspect’s condition is not currently available.

The Sioux City Police Department contacted the Iowa DCI to investigate the incident. The Iowa State Patrol also assisted in the investigation. Per department policy, involved officers were placed on administrative leave pending the outcome of an internal investigation. Further information will be released at the conclusion of the investigation.

-##-

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

[←](https://www.siouxcitypolice.com/news/2025/3/11/fatality-accident-at-hwy75-c80)[**March 11, 2025**\\
\\
Fatality Accident at Hwy75 & C80](https://www.siouxcitypolice.com/news/2025/3/11/fatality-accident-at-hwy75-c80)

[→](https://www.siouxcitypolice.com/news/2025/2/10/fatality-accident-on-feb-7-2025-25sc03446)[**February 10, 2025**\\
\\
Fatality Accident on Feb. 7, 2025 - 25SC03446](https://www.siouxcitypolice.com/news/2025/2/10/fatality-accident-on-feb-7-2025-25sc03446)