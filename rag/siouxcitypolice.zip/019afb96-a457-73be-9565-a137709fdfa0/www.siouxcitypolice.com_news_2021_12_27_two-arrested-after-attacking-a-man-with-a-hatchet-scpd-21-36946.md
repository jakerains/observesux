---
url: "https://www.siouxcitypolice.com/news/2021/12/27/two-arrested-after-attacking-a-man-with-a-hatchet-scpd-21-36946"
title: "Two arrested after attacking a man with a hatchet - SCPD #21-36946 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Two arrested after attacking a man with a hatchet - SCPD \#21-36946](https://www.siouxcitypolice.com/news/2021/12/27/two-arrested-after-attacking-a-man-with-a-hatchet-scpd-21-36946)

## December 27, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Two people have been arrested and charged for attacking another man with a hatchet earlier in the month.

On Dec. 18 at 6:55 AM, officers of the Sioux City Police Department were dispatched to the Dean Apartments, 1716 Nebraska Street, for a report of a stabbing.

The 61-year-old victim stated that he had been in his apartment with his brother when his brother opened the door for a female that they knew. Once the door was opened, a male entered and struck the victim with a hatchet on his shoulder causing a causing a life-threatening injury.

The victim and witness identified 52-year-old Mary Blair of Winnebago, Neb. as the female who had knocked on the door with the intention of getting the men to open the door so that the male suspect could attack the victim. This was due to an earlier argument between Blair and the victim in which Blair was made to leave the apartment of the victim.

Blair was arrested on Dec. 25 and charged with 1st degree burglary, going armed with intent, assault while participating in a felony, and willful injury-causing serious injury. All charges are felonies.

Detectives investigating the attack were able to identify 16-year-old Malachi Bassette of Winnebago, Neb. as the male party who attacked the victim. Bassette was arrested on Dec. 27 and charged with 1st degree burglary, going armed with intent, assault while participating in a felony, and willful injury-causing serious injury. He was booked into the Woodbury County Jail as he was charged an adult but is being held in the Woodbury County Juvenile Detention Center.

The victim underwent surgery and suffered a broken bone due to the assault . The victim has returned home to recover from his injuries.

![](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/efd420d4-078a-4fc4-843f-651282e24605/Blair.jpg)

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2021/12/30/local-law-enforcement-agencies-conduct-traffic-enforcement-project-on-i29)[**December 30, 2021**\\
\\
Local law enforcement agencies conduct traffic enforcement project on I29](https://www.siouxcitypolice.com/news/2021/12/30/local-law-enforcement-agencies-conduct-traffic-enforcement-project-on-i29)

[→](https://www.siouxcitypolice.com/news/2021/12/27/burglar-arrested-after-triggering-security-camera-scpd-21-37622)[**December 27, 2021**\\
\\
Burglar arrested after triggering security camera - SCPD #21-37622](https://www.siouxcitypolice.com/news/2021/12/27/burglar-arrested-after-triggering-security-camera-scpd-21-37622)