---
url: "https://www.siouxcitypolice.com/news/2022/5/2/felon-arrested-for-possessing-firearm-after-shots-fired-report-scpd-22-11432"
title: "Felon arrested for possessing firearm after shots fired report - SCPD #22-11432 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Felon arrested for possessing firearm after shots fired report - SCPD \#22-11432](https://www.siouxcitypolice.com/news/2022/5/2/felon-arrested-for-possessing-firearm-after-shots-fired-report-scpd-22-11432)

## May 2, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On May 1 at 8:47 p.m. the Sioux City Police Department received a report of shots being fired in the 100 block of Cecelia St.

Witnesses provided a description of a white Ford Taurus that was involved in the shooting.

Responding officers and deputies with the Woodbury County Sheriff’s Office located a vehicle matching the description fleeing the area at a high rate of speed.

The vehicle was stopped and the three occupants were detained.

While investigating the incident, officers located a firearm and shell casings in the car.

Officers charged 23-year-old Ethan S. Hewitt of Sioux City with dominion/control of a firearm/offense weapon by a felon.

Officers charged the driver, 24-year-old Collin J. Muston-Rosewall of Sioux City with operating while intoxicated.

The adult-female passenger was released without charges.

No victims or property damaged was located as a result of the shooting.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

[←](https://www.siouxcitypolice.com/news/2022/5/2/obin90x6dzze25tfqt7rt0dvs54qa6)[**May 02, 2022**\\
\\
Pursuit of burglary suspects ends in Le Mars - SCPD #22-10941](https://www.siouxcitypolice.com/news/2022/5/2/obin90x6dzze25tfqt7rt0dvs54qa6)

[→](https://www.siouxcitypolice.com/news/2022/5/2/man-arrested-for-stabbing-in-1700-block-of-pierce-st-scpd-22-10599)[**May 02, 2022**\\
\\
Man arrested for stabbing in 1700 block of Pierce St. - SCPD #22-10599](https://www.siouxcitypolice.com/news/2022/5/2/man-arrested-for-stabbing-in-1700-block-of-pierce-st-scpd-22-10599)