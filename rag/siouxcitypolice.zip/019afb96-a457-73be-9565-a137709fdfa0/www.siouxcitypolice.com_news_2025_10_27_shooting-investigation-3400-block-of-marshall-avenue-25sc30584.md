---
url: "https://www.siouxcitypolice.com/news/2025/10/27/shooting-investigation-3400-block-of-marshall-avenue-25sc30584"
title: "Shooting Investigation – 3400 block of Marshall Avenue 25SC30584 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shooting Investigation – 3400 block of Marshall Avenue 25SC30584](https://www.siouxcitypolice.com/news/2025/10/27/shooting-investigation-3400-block-of-marshall-avenue-25sc30584)

## October 27, 2025 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On October 25, 2025, at approximately 12:50 A.M. Sioux City Police Officers were dispatched to the 3400 block of Marshall Avenue for a report of a shooting.

Upon arrival, officers located one individual suffering from a gunshot wound to the abdomen. The victim was identified as Mario Armando Martinez Jr., 31, of Sioux City, Iowa. He was transported to Unity Point Health – St. Luke’s (Downtown) where he continues to receive treatment. His current condition is not being released at this time.

A suspect was also located at the scene and identified as Vicente Estrada Leon Jr., 35, of Sioux City, Iowa. Following the investigation, Leon was charged with:

• Willful Injury Resulting in Serious Injury

• Assault While Participating in a Felony

• Intimidation with a Dangerous Weapon

• Assault with a Dangerous Weapon

• Carrying a Weapon While Intoxicated

The Sioux City Police Department is committed to the safety and well-being of our community. We will provide updates as more information becomes available.

###

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[shooting](https://www.siouxcitypolice.com/news/tag/shooting),

[Crime](https://www.siouxcitypolice.com/news/tag/Crime)

←

[→](https://www.siouxcitypolice.com/news/2025/10/17/stabbing-on-october-11th-2025-25sc29172)[**October 17, 2025**\\
\\
Stabbing on October 11th, 2025 - 25SC29172](https://www.siouxcitypolice.com/news/2025/10/17/stabbing-on-october-11th-2025-25sc29172)