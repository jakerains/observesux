---
url: "https://www.siouxcitypolice.com/news/2022/9/27/teen-stabbed-by-unknown-man-during-altercation-22sc27238"
title: "Teen stabbed by unknown man during altercation - 22SC27238 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Teen stabbed by unknown man during altercation - 22SC27238](https://www.siouxcitypolice.com/news/2022/9/27/teen-stabbed-by-unknown-man-during-altercation-22sc27238)

## September 27, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Saturday September 24 at about 6:18 pm, the Sioux City Police Department responded to a report of a stabbing in the 1300 block of Jackson St.

Responding officers located a 17-year-old male suffering from a severe laceration to his neck. He was transported to MercyOne for treatment of his life-threatening injury.

Witnesses stated that the victim and a friend had been in front of a residence in the 1300 block of Jackson St. when a person not known to them, approached them, and started a confrontation. The unknown person pulled out a knife and stabbed the victim after the exchange became physical. It is not known why the man provoked a fight with the teens.

The suspect then fled the area and has not been located or identified.

Detectives are looking for a white male that is in his late 20’s or early 30’s. He is 5 foot 5 inches tall and has a slight build with his weight estimated to be about 120 pounds. He has light brown or dirty blonde hair. He was last seen wearing a flat billed baseball hat, baggy khaki shorts, and a “jersey” style t-shirt that was light blue and the sleeves were a different color that button or zipped up the front.

Anyone with information who this subject is or video footage of the area that may help identify the man is asked to call the Sioux City Police Department at 279-6440.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2022/9/27/8orrtk0dzwguncqgly7zogx7dwsubx)[**September 27, 2022**\\
\\
Shots fired call leads to pursuit - SCPD 22SC27393 & 22SC27394](https://www.siouxcitypolice.com/news/2022/9/27/8orrtk0dzwguncqgly7zogx7dwsubx)

[→](https://www.siouxcitypolice.com/news/2022/9/27/man-suffers-stab-wound-during-robbery-attempt-scpd-22sc27238)[**September 27, 2022**\\
\\
Man suffers stab wound during robbery attempt - SCPD 22SC27238](https://www.siouxcitypolice.com/news/2022/9/27/man-suffers-stab-wound-during-robbery-attempt-scpd-22sc27238)