---
url: "https://www.siouxcitypolice.com/news/2021/5/14/fatal-motorcycle-on-may-11-at-3290-n-martha-scpd-21-13654"
title: "Fatal motorcycle on May 11 at 3290 N. Martha - SCPD #21-13654 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Fatal motorcycle on May 11 at 3290 N. Martha - SCPD \#21-13654](https://www.siouxcitypolice.com/news/2021/5/14/fatal-motorcycle-on-may-11-at-3290-n-martha-scpd-21-13654)

## May 14, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

**Update May 13 at 8:00 a.m**. \- Investigators with the Sioux City Police Department identified 28-year-old Danny J. Sams of Sioux City as the victim of the single vehicle accident on May 11 at 3290 N. Martha St.

We wish to express our sympathies to his family for their loss.

A 33-year-old female was also injured in the accident and taken to a local hospital to be treated for her injuries. Her name is not being released at this time.

Traffic accident investigators are continuing their investigation into the accident.

**Original Release on May 12 at 2:30 a.m.** \- Investigation into fatal accident at 3290 North Martha St. is on going - SCPD #21-13654

The Sioux City Police Department responded to a accident involving injuries on May 11 at 10:33 p.m. at 3290 North Martha St. involving a motorcycle and a mobile home.

Responding officers found that a 1988 Harley Davidson motorcycle operated by a 28-year-old man had been driving eastbound at the Tallview Trailer Court and struck a new mobile home that was parked on the side of the road awaiting to be placed in a lot. After the collision there was a fire that burned the motorcycle and the rear portion of the mobile home. SCFD extinguished the fire and the male driver was transported to the hospital.

The male driver died due to the injuries sustained from the accident.

Traffic Investigators with the department are investigating contributing circumstances of the accident.

At this time, no charges have been filed as the investigation into the accident is ongoing.

The names of the parties involved are not being released at this time.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Fatality Accident](https://www.siouxcitypolice.com/news/tag/Fatality+Accident)

[←](https://www.siouxcitypolice.com/news/2021/6/7/suspect-sought-in-shooting-on-w-19th)[**June 07, 2021**\\
\\
Suspect sought in shooting on W. 19th](https://www.siouxcitypolice.com/news/2021/6/7/suspect-sought-in-shooting-on-w-19th)

[→](https://www.siouxcitypolice.com/news/2021/5/3/may-1st-homicide-investigation-21-12511)[**May 03, 2021**\\
\\
May 1st homicide investigation - #21-12511](https://www.siouxcitypolice.com/news/2021/5/3/may-1st-homicide-investigation-21-12511)