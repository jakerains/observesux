---
url: "https://www.siouxcitypolice.com/news/2022/3/21/shooting-on-ingleside-scpd-22-6619"
title: "Shooting on Ingleside - SCPD #22-6619 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shooting on Ingleside - SCPD \#22-6619](https://www.siouxcitypolice.com/news/2022/3/21/shooting-on-ingleside-scpd-22-6619)

## March 21, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On March 17, detectives charged 21-year-old Carlos D. Mejia of Sioux City with attempted murder, willful jury, and intimidation with a dangerous weapon for the shooting that occurred on March 14 at 1923 Ingleside.

Mejia had arranged for the adult-female victim to come to his residence to get money from him to use for the purchase of methamphetamine. When the victim arrived, she sent another woman to the door to get the money and Meija sent her away and asked for the victim.

When the victim came to the door, Mejia beckoned her inside where he was waiting in the kitchen. When she entered the back entry, Mejia had a gun in hand fired one bullet as she tried to flee. The victim suffered a gunshot wound to her abdomen which she sought medical treatment for. She is recovering at home. Mejia was booked into the Woodbury County Jail.

Original Release on March 14, 2022 at 9:36 p.m. – On March 14 at 1:50 p.m., the Sioux City Police Department received a report of a burglary to residence at 1923 Ingleside Ave. in which the caller stated a subject armed with a knife broke into his home and he fired a shot at her.

A few minutes later, an adult-female suffering from a gunshot wound came into MercyOne. She was treated for a serious injury and at the time of this release was still in the hospital. Officers determined that the woman with the gunshot wound was the person involved in the shooting on Ingleside. The adult-male resident reported that he shot the woman after she entered his home armed with a knife.

Detectives are continuing their investigation and are waiting to speak to the female who was injured.

At the time of this release, no charges have been filed. We are not releasing the names of the people

involved at this time.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

[←](https://www.siouxcitypolice.com/news/2022/3/21/pedestrian-struck-and-killed-on-i29-scp-22-6682)[**March 21, 2022**\\
\\
Pedestrian struck and killed on I29 - SCP #22-6682](https://www.siouxcitypolice.com/news/2022/3/21/pedestrian-struck-and-killed-on-i29-scp-22-6682)

[→](https://www.siouxcitypolice.com/news/2022/2/28/scpd-releases-preliminary-crime-statistics-for-2021)[**February 28, 2022**\\
\\
Preliminary crime statistics for 2021](https://www.siouxcitypolice.com/news/2022/2/28/scpd-releases-preliminary-crime-statistics-for-2021)