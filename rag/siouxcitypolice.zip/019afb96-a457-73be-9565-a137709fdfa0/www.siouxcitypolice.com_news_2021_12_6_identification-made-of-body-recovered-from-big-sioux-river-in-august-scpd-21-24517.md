---
url: "https://www.siouxcitypolice.com/news/2021/12/6/identification-made-of-body-recovered-from-big-sioux-river-in-august-scpd-21-24517"
title: "Identification made of body recovered from Big Sioux River in August - SCPD #21-24517 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Identification made of body recovered from Big Sioux River in August - SCPD \#21-24517](https://www.siouxcitypolice.com/news/2021/12/6/identification-made-of-body-recovered-from-big-sioux-river-in-august-scpd-21-24517)

## December 6, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Aug 21 at 6:05 p.m., the Sioux City Police Department responded to a report of a body being found in the Big Sioux River.

Due to the state of decay of the remains, detectives had to seek the assistance of the State Crime Lab and to use DNA to make a positive identification.

On Dec. 2, the lab notified the department that the person was positively identified as 24-year-old Franky Muritok of Sioux City.

We wish to express our sympathies to his family for their loss.

Muritok was reported missing on Aug. 15 after he had left to take his dog for a walk and did not return home. His dog was located tied up next to the river.

At this time, there is no indication of foul play and Muritok’s death appears to be accidental.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

[←](https://www.siouxcitypolice.com/news/2021/12/14/investigations-made-into-threats-against-schools-on-dec-14-scpd-21-36549-amp-21-36565)[**December 14, 2021**\\
\\
Investigations made into threats against schools on Dec. 14 - SCPD #21-36549 & 21-36565](https://www.siouxcitypolice.com/news/2021/12/14/investigations-made-into-threats-against-schools-on-dec-14-scpd-21-36549-amp-21-36565)

[→](https://www.siouxcitypolice.com/news/2021/12/2/pursuit-of-stolen-car-ends-after-pit-maneuver-scpd-21-35320)[**December 02, 2021**\\
\\
Pursuit of stolen car ends after PIT maneuver - SCPD #21-35320](https://www.siouxcitypolice.com/news/2021/12/2/pursuit-of-stolen-car-ends-after-pit-maneuver-scpd-21-35320)