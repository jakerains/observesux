---
url: "https://www.siouxcitypolice.com/news/2021/11/1/shooting-in-at-427-pierce-st-media-release"
title: "Shooting in at 427 Pierce St - SCPD #21-29897 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shooting in at 427 Pierce St - SCPD \#21-29897](https://www.siouxcitypolice.com/news/2021/11/1/shooting-in-at-427-pierce-st-media-release)

## November 1, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Original Release on Oct. 10, 2021 at 7:00 a.m. - On 10/10/21 at 3 :24 AM, Officers of the Sioux City Police Department were dispatched to 427 Pierce Street for a shots fired call.

When officers arrived on scene, they observed a male party suffering from a gunshot to his upper body. Officers rendered aid to the male victim, and he was transported to a local hospital for his life-threatening injuries.

Around 3:45 AM, the SCPD received multiple phone calls stating more victims were arriving at both local hospitals from this incident. All other parties are being treated for non-life-threatening injuries.

At this time, none of the victim ' s information will be released.

The investigation is still ongoing but if anyone has any information to help with this case please call 712-258-TIPS.

Share

[←](https://www.siouxcitypolice.com/news/2021/11/1/2600-block-of-douglas-st-shooting-scpd-21-30633)[**November 01, 2021**\\
\\
2600 Block of Douglas St. Shooting - SCPD #21-30633](https://www.siouxcitypolice.com/news/2021/11/1/2600-block-of-douglas-st-shooting-scpd-21-30633)

[→](https://www.siouxcitypolice.com/news/2021/9/29/cariaga-arrest-scpd-21-28610-21-24023-21-24319-amp-21-24307)[**September 29, 2021**\\
\\
Cariaga arrest - SCPD #21-28610, 21-24023, 21-24319, & 21-24307](https://www.siouxcitypolice.com/news/2021/9/29/cariaga-arrest-scpd-21-28610-21-24023-21-24319-amp-21-24307)