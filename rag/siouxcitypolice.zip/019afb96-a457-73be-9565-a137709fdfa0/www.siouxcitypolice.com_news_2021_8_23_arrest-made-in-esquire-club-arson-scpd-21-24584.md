---
url: "https://www.siouxcitypolice.com/news/2021/8/23/arrest-made-in-esquire-club-arson-scpd-21-24584"
title: "Arrest made in Esquire Club arson – SCPD #21-24584 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Arrest made in Esquire Club arson – SCPD \#21-24584](https://www.siouxcitypolice.com/news/2021/8/23/arrest-made-in-esquire-club-arson-scpd-21-24584)

## August 23, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

One person has been identified and charged in connection to the arson at the Esquire Club (also known as the After Set), 414 W. 7th St.

Detectives have charged 36-year-old Valon Jackson of Sioux City with 2nd degree arson, 1st degree criminal mischief, and 3rd degree burglary.

On Aug. 22 at 8:18 a.m., Sioux City Fire & Rescue responded to the club after reports of a fire were received.

The fire department determined that the cause of the fire was arson and a total estimate of the damage is not known but it is estimated to be over $20,000.

Jackson, along with an unidentified male, forced a door open and set the fire.

The motivation for the arson appears to be animosity towards the club.

Initial descriptions of the second suspect were of a black male but video evidence obtained shows a white male with Jackson.

The investigation into this matter is on-going.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Arson](https://www.siouxcitypolice.com/news/tag/Arson)

[←](https://www.siouxcitypolice.com/news/2021/8/30/man-dies-after-truck-goes-into-missouri-river)[**August 30, 2021**\\
\\
Man dies after truck goes into Missouri River.](https://www.siouxcitypolice.com/news/2021/8/30/man-dies-after-truck-goes-into-missouri-river)

[→](https://www.siouxcitypolice.com/news/2021/8/23/three-arrested-for-burglaries-and-possessing-stolen-weapons)[**August 23, 2021**\\
\\
Three arrested for burglaries and possessing stolen weapons](https://www.siouxcitypolice.com/news/2021/8/23/three-arrested-for-burglaries-and-possessing-stolen-weapons)