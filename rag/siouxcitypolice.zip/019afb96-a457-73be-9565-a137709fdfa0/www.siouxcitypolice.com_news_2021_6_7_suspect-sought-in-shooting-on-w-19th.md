---
url: "https://www.siouxcitypolice.com/news/2021/6/7/suspect-sought-in-shooting-on-w-19th"
title: "Suspect sought in shooting on W. 19th  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Suspect sought in shooting on W. 19th](https://www.siouxcitypolice.com/news/2021/6/7/suspect-sought-in-shooting-on-w-19th)

## June 7, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

UPDATE July 2 at 5:11 p.m - The U.S. Marshal Service Fugitive Task Force apprehended Corey D. Smith you in a vehicle outside of Dakota City, Neb. on July 2 around 4:30 p.m.

June 6 at 2:45 a.m. - (updated to include suspect description) On 6/5/2021 at approximately 10:22 hours, officers of the Sioux City Police Department were dispatched to the Hearthstone Apartments, 2300 block of W. 19th Street, Sioux City, IA for a shooting.

Officers arrived on scene and observed an adult male suffering from multiple gunshot wounds to his lower part of his body. Officers rendered aid to the male victim and the victim was transported to a local hospital where he was treated and released a short time later.

The shooter has been identified as 22-year-old Corey Deonte Smith of Sioux City, IA. Smith is considered armed and dangerous. Smith is 5 foot 11 inches, weighs 160 lbs, and has tattoos on his arms, chest, and neck.

The victim's name will not release until after 24 hours.

The investigation is still ongoing and no further information will be released at this time.

\*Information contained in this release is considered an accusation and any one listed is presumed innocent until and unless proven guilty.

![Corey D. Smith](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/1623072481399-HK75I5N98VEZX1TC9VY5/Corey+D.+Smith.jpg)

**Corey D. Smith**

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Crime](https://www.siouxcitypolice.com/news/tag/Crime)

[←](https://www.siouxcitypolice.com/news/2021/6/10/sioux-city-police-to-participate-in-traffic-safety-initiatives-this-summer)[**June 10, 2021**\\
\\
Sioux City Police to participate in traffic safety initiatives this summer](https://www.siouxcitypolice.com/news/2021/6/10/sioux-city-police-to-participate-in-traffic-safety-initiatives-this-summer)

[→](https://www.siouxcitypolice.com/news/2021/5/14/fatal-motorcycle-on-may-11-at-3290-n-martha-scpd-21-13654)[**May 14, 2021**\\
\\
Fatal motorcycle on May 11 at 3290 N. Martha - SCPD #21-13654](https://www.siouxcitypolice.com/news/2021/5/14/fatal-motorcycle-on-may-11-at-3290-n-martha-scpd-21-13654)