---
url: "https://www.siouxcitypolice.com/news/2022/10/5/public-needed-in-locating-missing-woman-22sc27903"
title: "Public help needed in locating missing woman - 22SC27903 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Public help needed in locating missing woman - 22SC27903](https://www.siouxcitypolice.com/news/2022/10/5/public-needed-in-locating-missing-woman-22sc27903)

## October 5, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

The Sioux City Police Department is asking for the public’s help in locating 36-year-old Brenda Payer of Sioux City.

Her family reported that they last had contact with her on Thursday September 29 when she parked her van in the McDonalds parking lot in the 700 block of Hamilton Blvd. Since then, her friends and family have been unable to contact her.

Payer is a native American woman with black hair and brown eyes, she is 5 foot 8 inches tall, and weighs 170 pounds.

We do not suspect foul play but are concerned for her mental health as she may be in crisis. We would like to locate her to ensure she is safe.

Anyone with information on her whereabouts is encouraged to contact the department at 279-6960. We are also encouraging Brenda to contact us to let us know if she needs assistance.

![](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/1c5d7229-a94a-4500-bdca-1b8dd95130dd/Payer+2.jpg)

![](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/d9364015-dab5-4760-94d3-632ab7d09bb9/Payer.jpg)

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[MMIW](https://www.siouxcitypolice.com/news/tag/MMIW),

[Missing Woman](https://www.siouxcitypolice.com/news/tag/Missing+Woman)

[←](https://www.siouxcitypolice.com/news/2022/10/24/2022-town-hall-meeting-held)[**October 24, 2022**\\
\\
2022 Town Hall Meeting Held](https://www.siouxcitypolice.com/news/2022/10/24/2022-town-hall-meeting-held)

[→](https://www.siouxcitypolice.com/news/2022/9/27/8orrtk0dzwguncqgly7zogx7dwsubx)[**September 27, 2022**\\
\\
Shots fired call leads to pursuit - SCPD 22SC27393 & 22SC27394](https://www.siouxcitypolice.com/news/2022/9/27/8orrtk0dzwguncqgly7zogx7dwsubx)