---
url: "https://www.siouxcitypolice.com/news/2022/5/2/shots-fired-call-results-in-kidnapping-arrest-scpd-8616"
title: "Shots fired call results in kidnapping arrest - SCPD #8616 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shots fired call results in kidnapping arrest - SCPD \#8616](https://www.siouxcitypolice.com/news/2022/5/2/shots-fired-call-results-in-kidnapping-arrest-scpd-8616)

## May 2, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On 4/2/22 at 4:08 PM, officers responded to a shots fired call at 1800 block of Jackson Street.

At 1808 Jackson Street officers observed a maroon Honda Odyssey with the front passenger window shot out and bullet hole in the hood. Officers also located multiple projectile impact holes in 1808 Jackson Streets garage.

Officers spoke to two witnesses that identified a male party carrying a rifle style weapon and described it as being a black and gray rifle between 3:00PM-4:00PM hours on today's date.

Officers were lead to 1812 Jackson Street and made contact with the same male party, a Capri Rogers that was seen carrying that black and gray weapon. Officers were granted consent to search Roger's residence and observed a .22 cal revolver and a black and gray shotgun. Officers discovered a female who is Roger's girlfriend inside the residence suffering from multiple serious injuries.

Capri Rogers, 34, of Sioux City, IA was arrested for Kidnapping 1st-Class A felony, Felon in possession of a firearm, Class D felony, Reckless Use ofa Firearm-Aggravted misdemeanor, Felony Domestic Assault, and Intimidation with a Dangerous Weapon - Class D felony.

At this time no more information will be released because the investigation is still ongoing.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

[←](https://www.siouxcitypolice.com/news/2022/5/2/shooting-in-1400-block-of-w-3rd-st-scpd-22-8729)[**May 02, 2022**\\
\\
Shooting in 1400 block of W. 3rd St. - SCPD #22-8729](https://www.siouxcitypolice.com/news/2022/5/2/shooting-in-1400-block-of-w-3rd-st-scpd-22-8729)

[→](https://www.siouxcitypolice.com/news/2022/3/29/shooting-700-block-of-18th-street-scpd-22-8110)[**March 29, 2022**\\
\\
Shooting 700 block of 18th Street - SCPD #22-8110](https://www.siouxcitypolice.com/news/2022/3/29/shooting-700-block-of-18th-street-scpd-22-8110)