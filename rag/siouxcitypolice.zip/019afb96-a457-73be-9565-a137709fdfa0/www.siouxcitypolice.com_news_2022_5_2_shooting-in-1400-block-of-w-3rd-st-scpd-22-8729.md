---
url: "https://www.siouxcitypolice.com/news/2022/5/2/shooting-in-1400-block-of-w-3rd-st-scpd-22-8729"
title: "Shooting in 1400 block of W. 3rd St. - SCPD #22-8729 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Shooting in 1400 block of W. 3rd St. - SCPD \#22-8729](https://www.siouxcitypolice.com/news/2022/5/2/shooting-in-1400-block-of-w-3rd-st-scpd-22-8729)

## May 2, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

\*\*\*Updated Release\*\*\* On 4//7/2022 at 10:30 AM, officers of the SCPD were able to identify and arrest the suspect from Uncle Dave's Bar.

Naji Shorter, 29, of Des Moines, IA was booked into the Woodbury County Jail for the following charges: Attempted Murder, Going armed with intent-Class D felony, Assault while paticpating in a felony- Class C, Willful Injury-Class C, and Prohibited person in possession of a firearm.

\*\*\*Orginal Press Release\*\*\*\*\* On 4/4/2022 at 12: 17 AM, officers of the SCPD were dispatched to Uncle Dave's Bar for a shooting.

Officers arrived on scene and observed a male party lying on the front steps suffering from a gunshot wound. The male was transported to a local hospital where he is being treated for serious injuries.

Officers are still conducting witness interviews and canvasing the area.

The SCPD asks if anyone has any information about this shooting to please come forward.

The victim's name will not be released at this time and no further information will be released since the investigation is still ongoing.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

[←](https://www.siouxcitypolice.com/news/2022/5/2/stabbing-amp-shots-fired-in-500-block-of-s-irene-scpd-22-8874)[**May 02, 2022**\\
\\
Stabbing & shots fired in 500 block of S. Irene - SCPD #22-8874](https://www.siouxcitypolice.com/news/2022/5/2/stabbing-amp-shots-fired-in-500-block-of-s-irene-scpd-22-8874)

[→](https://www.siouxcitypolice.com/news/2022/5/2/shots-fired-call-results-in-kidnapping-arrest-scpd-8616)[**May 02, 2022**\\
\\
Shots fired call results in kidnapping arrest - SCPD #8616](https://www.siouxcitypolice.com/news/2022/5/2/shots-fired-call-results-in-kidnapping-arrest-scpd-8616)