---
url: "https://www.siouxcitypolice.com/news/2021/8/23/homicide-in-the-200-block-of-21st-st-scpd-21-24583"
title: "Homicide in the 200 block of 21st ST – SCPD #21-24583 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Homicide in the 200 block of 21st ST – SCPD \#21-24583](https://www.siouxcitypolice.com/news/2021/8/23/homicide-in-the-200-block-of-21st-st-scpd-21-24583)

## August 23, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On August 22 at 9:28 a.m., the Sioux City Police Department received a report of a shooting at a residence in the 200 block of 21st St.

When officers arrived, they located 41-year-old Jason Lafferty of Sioux City had been shot and died as a result of the injury.

Officers also located a male party in the residence that had shot the victim and took him into custody.

Detectives have charged 52-year-old Robert D. Buel of Sioux City with 2nd degree murder and booked him into the Woodbury County Jail.

The shooting occurred after the victim and Buel were in an argument and the victim went to the garage. Buel went into the garage armed with a shotgun and handgun and pointed the shotgun at the victim. Buel then set the shotgun down and shot the victim with a handgun.

Buel and the victim were acquaintances and both resided at the residence as roommates.

We want to express our sympathy to the family of Jason for their tragic loss.

Share

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/8/23/three-arrested-for-burglaries-and-possessing-stolen-weapons)[**August 23, 2021**\\
\\
Three arrested for burglaries and possessing stolen weapons](https://www.siouxcitypolice.com/news/2021/8/23/three-arrested-for-burglaries-and-possessing-stolen-weapons)

[→](https://www.siouxcitypolice.com/news/2021/8/18/back-to-school-safety-tips)[**August 18, 2021**\\
\\
Back to School Safety Tips](https://www.siouxcitypolice.com/news/2021/8/18/back-to-school-safety-tips)