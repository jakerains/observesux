---
url: "https://www.siouxcitypolice.com/news/2021/9/29/man-charged-for-firing-gun-at-occupied-car-scpd-21-27288"
title: "Man charged for firing gun at occupied car - SCPD #21-27288 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man charged for firing gun at occupied car - SCPD \#21-27288](https://www.siouxcitypolice.com/news/2021/9/29/man-charged-for-firing-gun-at-occupied-car-scpd-21-27288)

## September 29, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Sept. 16 at 5:22 p.m., the Sioux City Police Department responded to a report of shots being fired in the 700 block of Center St.

Officers located a vehicle involved in the shooting a short distance away and stopped it at W 4th St and Wesley Park Way. Officers detained the two men inside.

The investigation determined that the two men detained followed another car to a residence in the 700 block of Center St. and the passenger fired a shot at the car that was occupied by an adult male, an adult female, a 6-year-old child, and a 4-year-old child. No one was injured in the shooting.

Detectives charged 18-year-old Jalond J. Hills of Sioux City with terrorism and going armed with intent.

The driver of the car, 19-year-old Charles J. Sully of Sioux City, was charged with failure to provide financial security (no car insurance) but was not charged with the shooting as it appeared he was not aware of Hills intent to shoot at the other car.

The cause of the dispute that led to this shooting is still under investigation.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-damaging-cars-scpd-21-27678)[**September 29, 2021**\\
\\
Man arrested after damaging cars - SCPD #21-27678](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-damaging-cars-scpd-21-27678)

[→](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-stabbing-at-convenience-store-scpd-21-26750)[**September 29, 2021**\\
\\
Man arrested after stabbing at convenience store - SCPD #21-26750](https://www.siouxcitypolice.com/news/2021/9/29/man-arrested-after-stabbing-at-convenience-store-scpd-21-26750)