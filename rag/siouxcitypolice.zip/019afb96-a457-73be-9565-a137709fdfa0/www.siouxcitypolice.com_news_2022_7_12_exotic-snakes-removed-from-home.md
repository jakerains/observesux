---
url: "https://www.siouxcitypolice.com/news/2022/7/12/exotic-snakes-removed-from-home"
title: "Exotic snakes removed from home.  — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Exotic snakes removed from home.](https://www.siouxcitypolice.com/news/2022/7/12/exotic-snakes-removed-from-home)

## July 12, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Officers with the Sioux City Police Department assisted Sioux City Animal Control in the execution of a search warrant to remove numerous exotic snakes and feeder mice that were being raised in a Sioux City home on July 11 shortly after 10 pm.

Officers were called to a home in the 4600 block of Harrison St. after a neighbor complained of finding a boa constrictor and feeder mice in his house.

Animal Control removed the animals and are caring for them at the Sioux City Animal Adoption and Rescue Center.

The home-owner was not at home at the time of the removal.

The matter has been referred to the City of Sioux City Legal Department for consideration of appropriate charges.

This is an on-going investigation.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2022/7/26/1xn59pzx91ibvj76r6a0ep2sroy035)[**July 26, 2022**\\
\\
SCPD receives 9th accreditation with CALEA](https://www.siouxcitypolice.com/news/2022/7/26/1xn59pzx91ibvj76r6a0ep2sroy035)

[→](https://www.siouxcitypolice.com/news/2022/6/30/guidance-on-the-new-atvutv-law-effective-july-1)[**June 30, 2022**\\
\\
Guidance on the new ATV/UTV law effective July 1](https://www.siouxcitypolice.com/news/2022/6/30/guidance-on-the-new-atvutv-law-effective-july-1)