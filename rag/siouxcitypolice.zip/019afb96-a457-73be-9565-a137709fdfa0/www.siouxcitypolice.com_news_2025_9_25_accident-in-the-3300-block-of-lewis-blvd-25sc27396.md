---
url: "https://www.siouxcitypolice.com/news/2025/9/25/accident-in-the-3300-block-of-lewis-blvd-25sc27396"
title: "Accident in the 3300 block of Lewis Blvd - 25SC27396 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Accident in the 3300 block of Lewis Blvd - 25SC27396](https://www.siouxcitypolice.com/news/2025/9/25/accident-in-the-3300-block-of-lewis-blvd-25sc27396)

## September 25, 2025 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

The Sioux City Police Department responded to an accident at 7:28 am on Sept. 25, when a car was struck by a semi in the 3300 block of Lewis Blvd./Business Highway 75N.

The car was driving across Lewis Blvd from a side street and when the semi that was traveling north on Lewis Blvd hit the car on the driver’s side.

An adult man was the only occupant of the car, and he was taken to a local hospital with life-threatening injuries. The semi driver was uninjured.

The initial investigation indicated that the car failed to wait at a stop sign before entering the busy four lane road.

No charges have been filed at the time of this release and the accident remains under investigation.

Released 9/25/25 at 11:15 am.

###

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Accidents](https://www.siouxcitypolice.com/news/tag/Accidents)

[←](https://www.siouxcitypolice.com/news/2025/9/27/homicide-600-block-of-14th-street-25sc27593)[**September 27, 2025**\\
\\
Homicide 600 Block of 14th Street - 25SC27593](https://www.siouxcitypolice.com/news/2025/9/27/homicide-600-block-of-14th-street-25sc27593)

[→](https://www.siouxcitypolice.com/news/2025/8/6/fatal-accident-at-3500-memorial-drive-25sc22084)[**August 06, 2025**\\
\\
Fatal Accident at 3500 Memorial Drive - 25SC22084](https://www.siouxcitypolice.com/news/2025/8/6/fatal-accident-at-3500-memorial-drive-25sc22084)