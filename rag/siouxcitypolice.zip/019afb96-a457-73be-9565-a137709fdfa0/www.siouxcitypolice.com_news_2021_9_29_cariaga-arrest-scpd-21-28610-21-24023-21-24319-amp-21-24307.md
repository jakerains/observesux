---
url: "https://www.siouxcitypolice.com/news/2021/9/29/cariaga-arrest-scpd-21-28610-21-24023-21-24319-amp-21-24307"
title: "Cariaga arrest - SCPD #21-28610, 21-24023, 21-24319, & 21-24307 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Cariaga arrest - SCPD \#21-28610, 21-24023, 21-24319, & 21-24307](https://www.siouxcitypolice.com/news/2021/9/29/cariaga-arrest-scpd-21-28610-21-24023-21-24319-amp-21-24307)

## September 29, 2021 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On Sept. 28 at 10:00 a.m., officers with the Sioux City Police Department arrested 21-year-old Alexio C. Cariaga of Sioux City in the 3400 block of Gordon Dr. for multiple warrants stemming from incidents in August.

Officers saw Cariaga walking in a parking lot of a hotel and approached him as they knew he had warrants for his arrest.

Cariaga was wanted in connection to two incidents that occurred in August of this year. On Aug. 17, he used a firearm to take money from a woman with whom he had been in a relationship with and had a child with. Then on Aug. 19, he forcefully entered a residence in the 1600 block of 27th St., struck that same woman and another male in the head with a handgun. He later fled from officers after crashing his car into a pole at 29th and Jackson St..

Cariaga was booked into the Woodbury County Jail on warrants for 1st degree robbery, felon in possession of a firearm, possession of a firearm by a domestic abuser, 1st degree burglary, domestic abuse assault, and probation violation.

**Original Release on August 20 at 3:22 p.m.** \- On August 19 at about 8:28 p.m., Officers responded to report of an assault at a residence in the 1600 block of 27th St. The suspect was not present when officers arrived.

Two adult victims reported being assaulted by the suspect who also was armed with a handgun. Minor injuries were reported.

A short time later, just before 9:00 p.m., an officer spotted the suspect driving on Jackson St. but the suspect fled on foot after striking a pole at 29th and Jackson.

Officers attempted to locate the suspect but where unsuccessful. A handgun was recovered from the suspects’ car.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police)

[←](https://www.siouxcitypolice.com/news/2021/11/1/shooting-in-at-427-pierce-st-media-release)[**November 01, 2021**\\
\\
Shooting in at 427 Pierce St - SCPD #21-29897](https://www.siouxcitypolice.com/news/2021/11/1/shooting-in-at-427-pierce-st-media-release)

[→](https://www.siouxcitypolice.com/news/2021/9/29/shooing-in-the-200-block-of-nebraska-st-scpd-21-28188)[**September 29, 2021**\\
\\
Shooing in the 200 block of Nebraska St - SCPD #21-28188](https://www.siouxcitypolice.com/news/2021/9/29/shooing-in-the-200-block-of-nebraska-st-scpd-21-28188)