---
url: "https://www.siouxcitypolice.com/news/2022/2/14/suspects-sought-in-riverside-shooting"
title: "Suspects sought in Riverside shooting SCPD #22-3986 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Suspects sought in Riverside shooting SCPD \#22-3986](https://www.siouxcitypolice.com/news/2022/2/14/suspects-sought-in-riverside-shooting)

## February 14, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On February 14 at 12:54 p.m., the Sioux City Police Department received reports of shots being fired at Riverside Blvd. and W. 19th St. in Sioux City.

Responding officers did not locate any victims of a shooting as all subjects involved had fled the area.

Officers canvassed the area and were able to locate shell casings and security camera video of the vehicles involved.

It appears at this time that the incident started in the 2400 block of Riverside Blvd., when an unidentified subject possibly in a late 2000s Nissan Versa fired several shots at another unknown subject in a newer dark gray Ford Escape.

Both cars left that area and traveled south on Riverside Blvd when the Ford Escape stopped at the intersection with W. 19th, exited his vehicle, and fired shots at the Nissan.

Both cars fled eastbound on W. 19th St. before officers arrived.

At the time of this release, no one has come forward as being a victim of the shooting. Officers did not locate any property that appeared to have been struck by bullets.

Officers are looking for a newer dark gray Ford Escape driven by a white male possibly with a beard and a light gray or white 2000’s Nissan Versa hatchback that is missing hubcaps on the passenger side.

Anyone involved in this or who had information on the identity of these subjects are asked to call the Sioux City Police Department at 279-6960.

Suspect cars from Riverside shooting on 2/14/22 - YouTube

[Photo image of SiouxCityPolice](https://www.youtube.com/channel/UCaptXpbLXzjyGXARY3h3uOA?embeds_referring_euri=https%3A%2F%2Fwww.siouxcitypolice.com%2F)

SiouxCityPolice

448 subscribers

[Suspect cars from Riverside shooting on 2/14/22](https://www.youtube.com/watch?v=Gd0115FXnxw)

SiouxCityPolice

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

More videos

## More videos

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=Gd0115FXnxw&embeds_referring_euri=https%3A%2F%2Fwww.siouxcitypolice.com%2F)

0:00

0:00 / 0:25

•Live

•

![](https://images.squarespace-cdn.com/content/v1/5759751cf85082ad8894f056/c456be7e-625f-4c2a-aa13-d94ef49c4121/suspect+cars.png)

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[shooting](https://www.siouxcitypolice.com/news/tag/shooting),

[Crime Sux](https://www.siouxcitypolice.com/news/tag/Crime+Sux)

[←](https://www.siouxcitypolice.com/news/2022/2/28/scpd-releases-preliminary-crime-statistics-for-2021)[**February 28, 2022**\\
\\
Preliminary crime statistics for 2021](https://www.siouxcitypolice.com/news/2022/2/28/scpd-releases-preliminary-crime-statistics-for-2021)

[→](https://www.siouxcitypolice.com/news/2022/2/10/barricaded-gunman-on-1100-block-of-grandview-blvd-scpd-22-3625)[**February 10, 2022**\\
\\
Barricaded gunman in 1100 block of Grandview Blvd. - SCPD #22-3625](https://www.siouxcitypolice.com/news/2022/2/10/barricaded-gunman-on-1100-block-of-grandview-blvd-scpd-22-3625)