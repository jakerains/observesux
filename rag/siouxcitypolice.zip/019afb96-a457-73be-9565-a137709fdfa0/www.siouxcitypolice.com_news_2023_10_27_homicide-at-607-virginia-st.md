---
url: "https://www.siouxcitypolice.com/news/2023/10/27/homicide-at-607-virginia-st"
title: "Homicide at 607 Virginia St. — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Homicide at 607 Virginia St.](https://www.siouxcitypolice.com/news/2023/10/27/homicide-at-607-virginia-st)

## October 27, 2023 [Tom Gill](https://www.siouxcitypolice.com/news?author=63ea7f77a18c4065afdf0421)

Released on October 27,2023 at 7:30am.

On October 26th, 2023 at 11:54 PM the Sioux City Police Department received a call of a female deceased in the parking lot of an apartment complex at 607 Virginia Street.

Officers arrived on scene and located an adult female suffering from multiple stab wounds. The victim was pronounced dead at the scene.

Officers conducted a canvas of the area, locating evidence of a stabbing at 607 Virginia apartment #107. Officers conducted an investigation and learned that an altercation had taken place inside the apartment.

Two suspects were located inside the apartment. The Sioux City Police Department arrested Angela M.Bino age 59 of Sioux City, and Jessica L. Bino age 32 of Sioux City. Both Subjects have been charged with 1st degree Murder.

The name and age of the victim is not being released at this time.

Anyone with information relating to this incident is encouraged to contact the Sioux City Police Department at 712-279-6440, or the anonymous tip line 712-258-TIPS (8477). The incident is still under investigation by the Sioux City Police Department. No other information is available at this time. A criminal charge is merely an accusation, and defendant(s) are presumed innocent until and unless proven guilty.

Share

[←](https://www.siouxcitypolice.com/news/2023/12/6/homicide)[**December 06, 2023**\\
\\
Homicide 513 9th Street](https://www.siouxcitypolice.com/news/2023/12/6/homicide)

[→](https://www.siouxcitypolice.com/news/2023/9/29/suspect-arrested-on-w-19th-shooting-1)[**September 29, 2023**\\
\\
Suspect arrested on W 19th shooting](https://www.siouxcitypolice.com/news/2023/9/29/suspect-arrested-on-w-19th-shooting-1)