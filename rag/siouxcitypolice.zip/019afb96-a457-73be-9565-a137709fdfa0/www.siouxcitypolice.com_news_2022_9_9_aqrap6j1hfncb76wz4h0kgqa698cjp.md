---
url: "https://www.siouxcitypolice.com/news/2022/9/9/aqrap6j1hfncb76wz4h0kgqa698cjp"
title: "Man arrested for August 29 shooting - SC#22-24458 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Man arrested for August 29 shooting - SC\#22-24458](https://www.siouxcitypolice.com/news/2022/9/9/aqrap6j1hfncb76wz4h0kgqa698cjp)

## September 9, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

The Sioux City Police Department has arrested a man in connection to a ”shots fired” report that occurred on August 29th in the 1000 block of Pierce Street.

Officers have charged 44-year-old Rico M. Willis of Sioux City with going armed with intent, possession of a firearm by a felon, possession of a controlled substance, and keeping a disorderly house.

The charges stem from the Aug. 29th incident when Willis followed an adult-male that he knew back to his apartment building. Willis confronted the man, pointed a handgun at him, and pulled the trigger. The gun failed to fire and Willis reloaded the firearm and then struck the victim with it. When Willis struck the man, the gun discharged.

No one was injured by the gunfire and no property was damaged.

Initially, this matter was investigated as a possible “road rage” incident but information was learned that determined that this was a dispute over a love interest between the two men.

On Sept. 9, officers served a search warrant on Willis’s residence a part of their investigation into this matter. During the search, officers located the firearm used as well as marijuana and drug paraphernalia.

Willis is a convicted felon and is prohibited from possession firearms.

Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed

Share

[←](https://www.siouxcitypolice.com/news/2022/9/23/scpd-investigates-post-on-social-media-that-caused-school-lock-outs)[**September 23, 2022**\\
\\
SCPD investigates post on social media that caused school lock-outs](https://www.siouxcitypolice.com/news/2022/9/23/scpd-investigates-post-on-social-media-that-caused-school-lock-outs)

[→](https://www.siouxcitypolice.com/news/2022/9/6/speed-violations-and-accident-trend-down-after-cameras-installed)[**September 06, 2022**\\
\\
Speed violations and accident trend down after cameras installed](https://www.siouxcitypolice.com/news/2022/9/6/speed-violations-and-accident-trend-down-after-cameras-installed)