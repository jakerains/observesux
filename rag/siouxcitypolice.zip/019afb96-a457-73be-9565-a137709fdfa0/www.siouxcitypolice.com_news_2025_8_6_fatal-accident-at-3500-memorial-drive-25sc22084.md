---
url: "https://www.siouxcitypolice.com/news/2025/8/6/fatal-accident-at-3500-memorial-drive-25sc22084"
title: "Fatal Accident at 3500 Memorial Drive - 25SC22084 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Fatal Accident at 3500 Memorial Drive - 25SC22084](https://www.siouxcitypolice.com/news/2025/8/6/fatal-accident-at-3500-memorial-drive-25sc22084)

## August 6, 2025 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

On August 6th, 2025 at 02:21 AM the Sioux City Police Department received a call of a single Vehicle accident in the area of 3500 blk of Memorial Dr.

Officers arrived on scene and located a single vehicle accident with one occupant in the vehicle.

Sioux City Police Officers attended to the victim, until Sioux City Fire and Rescue arrived on scene.

The victim was pronounced deceased at the scene.

Officers conducted an accident investigation of the initial scene.

At this time the victim is not being identified pending notification of the family.

The incident is still under investigation by the Sioux City Police Department.

No other information is available at this time.

###

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

_tags_ [Sioux City Police](https://www.siouxcitypolice.com/news/tag/Sioux+City+Police),

[Sioux City](https://www.siouxcitypolice.com/news/tag/Sioux+City),

[Fatality Accident](https://www.siouxcitypolice.com/news/tag/Fatality+Accident)

[←](https://www.siouxcitypolice.com/news/2025/9/25/accident-in-the-3300-block-of-lewis-blvd-25sc27396)[**September 25, 2025**\\
\\
Accident in the 3300 block of Lewis Blvd - 25SC27396](https://www.siouxcitypolice.com/news/2025/9/25/accident-in-the-3300-block-of-lewis-blvd-25sc27396)

[→](https://www.siouxcitypolice.com/news/2025/5/22/barricaded-subject-900-block-of-21st-street)[**May 22, 2025**\\
\\
Barricaded Subject 900 block of 21st Street - 25SC14048](https://www.siouxcitypolice.com/news/2025/5/22/barricaded-subject-900-block-of-21st-street)