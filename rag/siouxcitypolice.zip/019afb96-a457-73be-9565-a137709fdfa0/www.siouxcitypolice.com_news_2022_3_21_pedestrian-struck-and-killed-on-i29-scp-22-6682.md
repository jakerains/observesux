---
url: "https://www.siouxcitypolice.com/news/2022/3/21/pedestrian-struck-and-killed-on-i29-scp-22-6682"
title: "Pedestrian struck and killed on I29 - SCP #22-6682 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Pedestrian struck and killed on I29 - SCP \#22-6682](https://www.siouxcitypolice.com/news/2022/3/21/pedestrian-struck-and-killed-on-i29-scp-22-6682)

## March 21, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

Officers have identified 53-year-old Christian J. Sanchez of Sioux City as the pedestrian struck on I-29 during the early morning hours of March 15.

We wish to express our sympathy to his family for their loss.

Officers are still investigating why Sanchez was walking on the interstate at that time, but foul play is not suspected.

Based on available information, no one will be charged in this matter.

The investigation in on-going.

Original Release of March 15, 2022 at 6:40 a.m. – On March 15 at 4:10 a.m., the Sioux City Police Department responded to a reported a pedestrian being struck by a vehicle near mile marker 150.9 on I-29 in the northbound lane.

The adult-male struck died as a result of injuries he received.

It is not known why the man was in the roadway but witnesses reported he was in the middle of the roadway. The investigation is on-going.

No other injuries were reported.

The name of deceased will be released 24 hours after his next-of-kin are notified.

Share

_categories_ [Press Release](https://www.siouxcitypolice.com/news/category/Press+Release)

[←](https://www.siouxcitypolice.com/news/2022/3/21/shooting-1600-block-of-nebraska-st-scpd-22-7338)[**March 21, 2022**\\
\\
Shooting 1600 block of Nebraska St. - SCPD #22-7338](https://www.siouxcitypolice.com/news/2022/3/21/shooting-1600-block-of-nebraska-st-scpd-22-7338)

[→](https://www.siouxcitypolice.com/news/2022/3/21/shooting-on-ingleside-scpd-22-6619)[**March 21, 2022**\\
\\
Shooting on Ingleside - SCPD #22-6619](https://www.siouxcitypolice.com/news/2022/3/21/shooting-on-ingleside-scpd-22-6619)