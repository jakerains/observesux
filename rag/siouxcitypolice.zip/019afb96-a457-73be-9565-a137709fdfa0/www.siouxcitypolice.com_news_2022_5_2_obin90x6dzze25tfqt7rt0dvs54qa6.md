---
url: "https://www.siouxcitypolice.com/news/2022/5/2/obin90x6dzze25tfqt7rt0dvs54qa6"
title: "Pursuit of burglary suspects ends in Le Mars - SCPD #22-10941 — Sioux City Police Department"
---

ACCIDENT ALERT - DECEMBER 6, 2025: Report minor accidents at [https://iowadot.forms.govos.com/f/EQBHMf](https://iowadot.forms.govos.com/f/EQBHMf)

### Contact Us

Use the form on the right to contact us.

NOTICE: Messages are **not monitored 24 hours a day**.

If you need to report a crime or need immediate assistance, call **712-279-6960.**

## **If you have an emergency, call 911.**

Email Address(required)

Message(required)

SubmitSubmit

[View map in new window](https://maps.google.com/maps?q=42.496607,-96.40682070000003 "View map in new window")

601 Douglas Street

Sioux City, IA, 51101

United States

7122796440

[SiouxCityPolice@sioux-city.org](mailto:SiouxCityPolice@sioux-city.org)

# [Sioux City Police Department](https://www.siouxcitypolice.com/)

Info

Email

[Search](https://www.siouxcitypolice.com/search)

# News

Updates and Information on the Community and Your Department

# [Pursuit of burglary suspects ends in Le Mars - SCPD \#22-10941](https://www.siouxcitypolice.com/news/2022/5/2/obin90x6dzze25tfqt7rt0dvs54qa6)

## May 2, 2022 [Jeremy McClure](https://www.siouxcitypolice.com/news?author=5c6dc3cedb792698ae90a839)

**UPDATE April 27 at 1:30 pm**\- Detectives with the Sioux City Police Department have charged 35-year-old Amy Cruz of Colorado with 3rd degree burglary, two counts of 1st degree theft, two counts of possession of a controlled substance, and failure to affix a drug tax stamp.

These charges are from the investigation into the burglary of Sioux City Ford in which Cruz and a male accomplice broke into the dealership, stole a pickup truck and tools.

Cruz was apprehended when the stolen truck she was a passenger in crashed.

Approximately 150 pounds of what appears to be marijuana and a pound of methamphetamine were also located in the vehicle Cruz and accomplice were in.

Cruz is currently in the Woodbury County Jail and the adult-male accomplice is recovering at a local hospital from injuries he sustained in the crash.

The investigation into this matter is on-going.

**Original Release on April 27, 2022 at 1:30 p.m**. \- On April 27 at 3:21 a.m., the Sioux City Police Department responded to a report of a burglary in progress at Sioux City Ford, 3601 Singing Hills Blvd.

Before officers could arrive, the suspects fled the scene in a box truck rented from another state and a pickup truck that they stole from the dealership.

A short time later, deputies with the Woodbury County Sheriff’s Office located the fleeing vehicles traveling on Highway 75 and a pursuit ensued.

The fleeing vehicles entered Plymouth County and continued their attempt to elude officers. During the pursuit, the box truck was abandoned and both suspects continued their attempt to elude officers.

The pursuit ended in Le Mars when the stolen truck struck another vehicle in traffic.

The adult-male driver of the stolen truck was taken to MercyOne in Sioux City and is being treated for serious injuries.

Arrested was 35-year-old Amy L. Cruz of Colorado for a warrant out of Colorado and she currently is being held in the Woodbury County Jail.

Detectives with the Sioux City Police Department are investigating the burglary and additional crimes the two may have committed.

The investigation into this matter is on-going.

The Iowa State Patrol, Plymouth County Sheriff’s Office, and Woodbury County Sheriff’s Office are responsible for the apprehension of these subjects and are assisting in the investigation.

_Any arrest/charge noted in this report should be considered merely an accusation. Any defendant is presumed innocent until and unless proven guilty._

Share

[←](https://www.siouxcitypolice.com/news/2022/5/16/scpd-holds-annual-awards-ceremony)[**May 16, 2022**\\
\\
SCPD holds annual awards ceremony](https://www.siouxcitypolice.com/news/2022/5/16/scpd-holds-annual-awards-ceremony)

[→](https://www.siouxcitypolice.com/news/2022/5/2/felon-arrested-for-possessing-firearm-after-shots-fired-report-scpd-22-11432)[**May 02, 2022**\\
\\
Felon arrested for possessing firearm after shots fired report - SCPD #22-11432](https://www.siouxcitypolice.com/news/2022/5/2/felon-arrested-for-possessing-firearm-after-shots-fired-report-scpd-22-11432)